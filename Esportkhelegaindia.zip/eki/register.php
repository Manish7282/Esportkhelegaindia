<?php
include 'db.php'; // Make sure this file connects to your MySQL database ($conn)

$registration_error_message = ''; // Initialize error message string
$success_message = ''; // Initialize success message string (though current flow uses JS alert for success)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $raw_password = $_POST['password']; // Get raw password for validation

    // Basic Server-side validation
    if (empty($name) || empty($email) || empty($raw_password)) {
        $registration_error_message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $registration_error_message = "Invalid email format.";
    } elseif (strlen($raw_password) < 6) {
        $registration_error_message = "Password must be at least 6 characters long.";
    }
    // Add other validations as needed (e.g., terms checked server-side if crucial)
    // For this example, we'll assume terms are handled client-side or not strictly enforced server-side for error display

    if (empty($registration_error_message)) {
        // Proceed with registration if no initial validation errors
        $password = password_hash($raw_password, PASSWORD_DEFAULT);

        // Check if email already exists BEFORE attempting insert
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        if ($stmt_check) {
            $stmt_check->bind_param("s", $email);
            $stmt_check->execute();
            $stmt_check->store_result();

            if ($stmt_check->num_rows > 0) {
                $registration_error_message = 'This email is already registered. Please <a href="login.php" style="color: var(--green); text-decoration: underline;">log in</a>.';
            }
            $stmt_check->close();
        } else {
            error_log("Prepare failed for email check: (" . $conn->errno . ") " . $conn->error);
            $registration_error_message = 'An error occurred during pre-registration check. Please try again later.';
        }


        if (empty($registration_error_message)) { // Only attempt insert if email is not already registered and no other errors
            $stmt_insert = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            if ($stmt_insert) {
                $stmt_insert->bind_param("sss", $name, $email, $password);

                if ($stmt_insert->execute()) {
                    // Success: Use JS alert and redirect as before, or set a success message for the login page.
                    // For consistency with your original request, we keep the JS alert.
                    echo "<script>alert('Registered successfully!'); window.location.href = 'login.php';</script>";
                    exit(); // Crucial to stop further script execution
                } else {
                    // This error might occur if the email check somehow failed but the constraint still caught it,
                    // or for other unexpected DB errors.
                    error_log("Insert failed: (" . $stmt_insert->errno . ") " . $stmt_insert->error);
                    $registration_error_message = 'Registration failed due to a server error. Please try again later.';
                }
                $stmt_insert->close();
            } else {
                 error_log("Prepare failed for insert: (" . $conn->errno . ") " . $conn->error);
                 $registration_error_message = 'An error occurred preparing your registration. Please try again later.';
            }
        }
    }
    // $conn->close(); // Connection will be closed automatically at script end if not handled by db.php
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Register - Tiranga Theme</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    :root {
      --saffron: #FF9933;
      --white: #FFFFFF;
      --green: #138808;
      --navy-blue: #0033A0;

      --dark-bg: #121212;
      --container-bg: #1E1E1E;
      --input-bg: #2C2C2C;
      --input-border: #4A4A4A;
      --input-border-focus: var(--green);

      --light-text: #E0E0E0;
      --dim-text: #888888;
      --label-active-color: var(--saffron);

      --saffron-rgb: 255, 153, 51;
      --green-rgb: 19, 136, 8;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    body {
      background: var(--dark-bg);
      color: var(--light-text);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 15px;
    }
    .wrapper {
      background: var(--container-bg);
      padding: 40px 30px;
      border-radius: 12px;
      box-shadow: 0 5px 20px rgba(var(--saffron-rgb), 0.2);
      width: 100%;
      max-width: 400px;
      opacity: 0;
      animation: fadeIn 0.8s forwards;
      border-top: 4px solid var(--saffron);
    }
    form h2 {
      text-align: center;
      margin-bottom: 25px;
      color: var(--saffron);
      font-weight: 700;
      opacity: 0;
      animation: slideDown 0.8s forwards;
      animation-delay: 0.3s;
    }
    .input-group {
      position: relative;
      margin-bottom: 25px;
      opacity: 0;
      animation: slideUp 0.8s forwards;
    }
    .input-group:nth-of-type(1) { animation-delay: 0.4s; }
    .input-group:nth-of-type(2) { animation-delay: 0.55s; }
    .input-group:nth-of-type(3) { animation-delay: 0.7s; }

    .input-group input {
      width: 100%;
      padding: 12px 10px;
      background: var(--input-bg);
      border: 1px solid var(--input-border);
      border-radius: 6px;
      color: var(--light-text);
      font-size: 16px;
      transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }
    .input-group input:focus {
        border-color: var(--input-border-focus);
        outline: none;
        box-shadow: 0 0 8px rgba(var(--green-rgb), 0.3);
    }
    .input-group label {
      position: absolute;
      left: 12px;
      top: 12px;
      color: var(--dim-text);
      pointer-events: none;
      transition: 0.2s ease all;
      font-size: 14px;
    }
    .input-group input:focus + label,
    .input-group input:not(:placeholder-shown) + label {
      top: -10px;
      font-size: 12px;
      color: var(--label-active-color);
      background: var(--container-bg);
      padding: 0 6px;
    }
    .password-wrapper { position: relative; }
    .password-wrapper input { padding-right: 40px; }
    .toggle-password {
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      color: var(--dim-text);
      font-size: 16px; /* Adjusted size */
      user-select: none;
      transition: color 0.3s ease;
    }
    .toggle-password:hover { color: var(--saffron); }

    .remember {
      margin-bottom: 20px;
      font-size: 14px;
      color: var(--light-text);
      opacity: 0;
      animation: slideUp 0.8s forwards;
      animation-delay: 0.85s;
    }
    .remember input[type="checkbox"] {
      margin-right: 8px;
      transform: scale(1.2);
      cursor: pointer;
      accent-color: var(--green);
    }
    button[type="submit"] {
      width: 100%;
      background: gray;
      border: none;
      padding: 12px;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 700;
      color: var(--light-text);
      cursor: not-allowed;
      transition: background 0.3s ease, box-shadow 0.3s ease, color 0.3s ease;
      opacity: 0;
      animation: slideUp 0.8s forwards;
      animation-delay: 1s;
    }
    button[type="submit"]:enabled {
      background: var(--green);
      color: var(--white);
      cursor: pointer;
      box-shadow: 0 0 12px rgba(var(--green-rgb), 0.4);
    }
    button[type="submit"]:enabled:hover {
        background: var(--saffron);
        color: var(--dark-bg);
        box-shadow: 0 0 15px rgba(var(--saffron-rgb), 0.5);
    }

    .signUp-link {
      margin-top: 20px;
      text-align: center;
      font-size: 14px;
      color: var(--dim-text);
      opacity: 0;
      animation: fadeIn 0.8s forwards;
      animation-delay: 1.2s;
    }
    .signUp-link a {
      color: var(--saffron);
      text-decoration: none;
      font-weight: 600;
    }
    .signUp-link a:hover {
      text-decoration: underline;
      color: var(--green);
    }

    /* Error Message Box Style */
    .error-message-box {
      background-color: rgba(var(--saffron-rgb), 0.15);
      color: var(--saffron);
      border: 1px solid var(--saffron);
      padding: 10px 15px;
      border-radius: 6px;
      margin-bottom: 20px;
      text-align: center;
      font-size: 14px;
      animation: fadeIn 0.5s ease;
    }
    .error-message-box a {
        color: var(--green);
        text-decoration: underline;
        font-weight: bold;
    }
    .error-message-box a:hover {
        color: #106c07;
    }

    @media (max-width: 480px) { .wrapper { padding: 30px 20px; } }
    @keyframes fadeIn { to { opacity: 1; } }
    @keyframes slideDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
  </style>
</head>
<body>

  <div class="wrapper">
    <div class="form-wrapper">
      <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="return validateForm()">
        
        <?php if (!empty($registration_error_message)): ?>
          <div class="error-message-box">
            <?php echo $registration_error_message; // Outputting HTML directly as it may contain a trusted link ?>
          </div>
        <?php endif; ?>

        <h2>Register</h2>

        <div class="input-group">
          <input type="text" name="name" id="name" placeholder=" " required value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" />
          <label for="name">Full Name</label>
        </div>

        <div class="input-group">
          <input type="email" name="email" id="email" placeholder=" " required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" />
          <label for="email">Email Address</label>
        </div>

        <div class="input-group password-wrapper">
          <input type="password" name="password" id="password" placeholder=" " required minlength="6" />
          <label for="password">Create Password</label>
          <i class="fa-solid fa-eye toggle-password" id="togglePassword"></i>
        </div>

        <div class="remember">
          <label><input type="checkbox" id="terms" /> I agree to the terms & conditions</label>
        </div>

        <button type="submit" id="submitBtn" disabled>Sign Up</button>

        <div class="signUp-link">
          <p>Already have an account? <a href="login.php" class="signInBtn-link">Log In</a></p>
        </div>
      </form>
    </div>
  </div>

<script>
  const termsCheckbox = document.getElementById('terms');
  const submitBtn = document.getElementById('submitBtn');
  const togglePassword = document.getElementById('togglePassword');
  const passwordInput = document.getElementById('password');
  const nameInput = document.getElementById('name'); // Get name input
  const emailInput = document.getElementById('email'); // Get email input

  function updateSubmitButtonState() {
    const nameFilled = nameInput.value.trim() !== '';
    const emailFilled = emailInput.value.trim() !== '';
    const passwordFilled = passwordInput.value.trim() !== ''; // Or check length if you prefer

    if (termsCheckbox.checked && nameFilled && emailFilled && passwordFilled) {
        submitBtn.disabled = false;
        submitBtn.style.background = ''; // Reset to CSS defined :enabled color
    } else {
        submitBtn.disabled = true;
        submitBtn.style.background = 'gray'; // Explicitly set disabled color
    }
  }

  // Event listeners for inputs and checkbox
  [termsCheckbox, nameInput, emailInput, passwordInput].forEach(element => {
      element.addEventListener('input', updateSubmitButtonState); // 'input' for text fields, 'change' for checkbox
      if(element.type === 'checkbox') element.addEventListener('change', updateSubmitButtonState);
  });


  togglePassword.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    togglePassword.classList.toggle('fa-eye');
    togglePassword.classList.toggle('fa-eye-slash');
  });

  function validateForm() {
    // Client-side validation (can be more robust)
    if (nameInput.value.trim() === '') {
        alert("Please enter your full name.");
        nameInput.focus();
        return false;
    }
    if (emailInput.value.trim() === '' || !emailInput.checkValidity()) { // checkValidity for basic email format
        alert("Please enter a valid email address.");
        emailInput.focus();
        return false;
    }
    if (passwordInput.value.length < 6) {
        alert("Password must be at least 6 characters long.");
        passwordInput.focus();
        return false;
    }
    if (!termsCheckbox.checked) {
      alert("Please agree to the terms & conditions to continue.");
      return false;
    }
    return true;
  }

  // Initial state for the button
  updateSubmitButtonState();
</script>

</body>
</html>