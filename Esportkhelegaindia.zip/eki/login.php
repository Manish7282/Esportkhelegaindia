<?php
session_start();
include 'db.php'; // Make sure this file connects to your MySQL database ($conn)

$login_error_message = ''; // Initialize an empty error message string

if (isset($_SESSION['user_id'])) {
    // If already logged in, redirect to profile
    header("Location: profile.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $login_error_message = 'Please fill in both email and password.';
    } else {
        $stmt = $conn->prepare("SELECT id, name, email, password FROM users WHERE email = ?");
        
        if (!$stmt) {
            error_log("Prepare failed: (" . $conn->errno . ") " . $conn->error);
            $login_error_message = 'An error occurred. Please try again later.';
        } else {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($id, $name, $user_db_email, $hashed_password);
                $stmt->fetch();

                if (password_verify($password, $hashed_password)) {
                    $_SESSION['user_id'] = $id;
                    $_SESSION['user_name'] = $name;
                    $_SESSION['user_email'] = $user_db_email; // Store user's email in session
                    session_regenerate_id(true); // Security best practice
                    
                    $stmt->close();
                    header("Location: profile.php");
                    exit();
                } else {
                    // Email found, but password incorrect
                    $login_error_message = 'You have entered the wrong password. Please try again.';
                }
            } else {
                // Email not found in the database
                $login_error_message = 'This email is not registered. Please <a href="Register.php" style="color: var(--green); text-decoration: underline;">register</a> first.';
            }
            $stmt->close(); 
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login - Tiranga Theme</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    :root {
      --saffron: #FF9933;
      --white: #FFFFFF;
      --green: #138808;
      --navy-blue: #0033A0; /* For borders or subtle accents */

      --dark-bg: #121212;
      --container-bg: #1E1E1E;
      --input-bg: #2C2C2C;
      --input-border: #4A4A4A;
      --input-border-focus: var(--green);

      --light-text: #E0E0E0;
      --dim-text: #888888;
      --label-active-color: var(--saffron);

      /* RGB versions for rgba() shadows */
      --saffron-rgb: 255, 153, 51;
      --green-rgb: 19, 136, 8;
    }

    /* Reset & base */
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    body {
      background: var(--dark-bg);
      color: var(--light-text);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 15px;
    }
    .wrapper {
      background: var(--container-bg);
      padding: 40px 30px;
      border-radius: 12px;
      box-shadow: 0 5px 20px rgba(var(--saffron-rgb), 0.2); /* Saffron shadow */
      width: 100%;
      max-width: 400px;
      animation: fadeIn 0.8s ease forwards;
      opacity: 0;
      border-top: 4px solid var(--saffron); /* Saffron top accent */
    }
    form h2 {
      text-align: center;
      margin-bottom: 25px;
      color: var(--saffron); /* Saffron heading */
      font-weight: 700;
      letter-spacing: 1.2px;
      animation: slideDown 0.8s ease forwards;
      opacity: 0;
    }
    .input-group {
      position: relative;
      margin-bottom: 25px;
      animation: slideUp 0.8s ease forwards;
      opacity: 0;
    }
    form .input-group:nth-of-type(1) {
      animation-delay: 0.3s;
    }
    form .input-group:nth-of-type(2) {
      animation-delay: 0.45s;
    }
    .input-group input {
      width: 100%;
      padding: 12px 10px;
      background: var(--input-bg);
      border: 1px solid var(--input-border);
      border-radius: 6px;
      color: var(--light-text);
      font-size: 16px;
      transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }
    .input-group input:focus {
      border-color: var(--input-border-focus);
      box-shadow: 0 0 8px rgba(var(--green-rgb), 0.3);
      outline: none;
    }
    .input-group label {
      position: absolute;
      left: 12px;
      top: 12px;
      color: var(--dim-text);
      pointer-events: none;
      transition: 0.3s ease all;
      font-size: 14px;
      background: transparent;
    }
    .input-group input:focus + label,
    .input-group input:not(:placeholder-shown) + label {
      top: -10px;
      font-size: 12px;
      color: var(--label-active-color);
      background: var(--container-bg);
      padding: 0 6px;
    }
    .input-group .toggle-password {
      position: absolute;
      top: 50%;
      right: 12px;
      transform: translateY(-50%);
      cursor: pointer;
      color: var(--dim-text);
      font-size: 16px;
      user-select: none;
      transition: color 0.3s ease;
    }
    .input-group .toggle-password:hover {
      color: var(--saffron);
    }
    .remember {
      margin-bottom: 20px;
      font-size: 14px;
      text-align: right;
      animation: slideUp 0.8s ease forwards;
      opacity: 0;
      animation-delay: 0.6s;
    }
    .remember a {
      color: var(--saffron);
      text-decoration: none;
      font-weight: 600;
      transition: color 0.3s ease, text-decoration 0.3s ease;
    }
    .remember a:hover {
      text-decoration: underline;
      color: var(--green);
    }
    button[type="submit"] {
      width: 100%;
      background: var(--green);
      border: none;
      padding: 12px;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 700;
      color: var(--white);
      cursor: pointer;
      transition: background 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
      animation: slideUp 0.8s ease forwards;
      opacity: 0;
      animation-delay: 0.75s;
    }
    button[type="submit"]:hover {
      background: var(--saffron);
      color: var(--dark-bg);
      box-shadow: 0 0 15px rgba(var(--saffron-rgb), 0.5);
      transform: scale(1.02);
    }
    .signUp-link {
      margin-top: 20px;
      text-align: center;
      font-size: 14px;
      color: var(--dim-text);
      animation: fadeIn 1.2s ease forwards;
      opacity: 0;
      animation-delay: 1s;
    }
    .signUp-link a {
      color: var(--saffron);
      text-decoration: none;
      font-weight: 600;
      transition: color 0.3s ease, text-decoration 0.3s ease;
    }
    .signUp-link a:hover {
      text-decoration: underline;
      color: var(--green);
    }

    /* Error Message Box Style */
    .error-message-box {
      background-color: rgba(var(--saffron-rgb), 0.15); /* Light saffron background */
      color: var(--saffron); /* Saffron text for error */
      border: 1px solid var(--saffron);
      padding: 10px 15px;
      border-radius: 6px; /* Match input radius */
      margin-bottom: 20px;
      text-align: center;
      font-size: 14px;
      animation: fadeIn 0.5s ease; /* Simple fade in for error */
    }
     /* Style for link within error message */
    .error-message-box a {
        color: var(--green); /* Green link as requested */
        text-decoration: underline;
        font-weight: bold;
    }
    .error-message-box a:hover {
        color: #106c07; /* Darker green on hover */
    }


    @media (max-width: 480px) {
      .wrapper {
        padding: 30px 20px;
      }
    }
    @keyframes fadeIn { to { opacity: 1; } }
    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes slideUp {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>

  <div class="wrapper">
    <div class="form-wrapper sign-in">
      <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        
        <?php if (!empty($login_error_message)): ?>
          <div class="error-message-box">
            <?php echo $login_error_message; // Outputting HTML directly as it contains a trusted link ?>
          </div>
        <?php endif; ?>

        <h2>Login</h2>

        <div class="input-group">
          <input type="email" name="email" id="email" placeholder=" " required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" />
          <label for="email">Email</label>
        </div>

        <div class="input-group">
          <input type="password" name="password" id="password" placeholder=" " required />
          <label for="password">Password</label>
          <i class="fas fa-eye toggle-password" id="togglePassword"></i>
        </div>

        <div class="remember">
          <a href="forgot_password.php">Forgot Password?</a>
        </div>

        <button type="submit">Login</button>

        <div class="signUp-link">
          <p>Don't have an account? <a href="Register.php">Register</a></p>
        </div>
      </form>
    </div>
  </div>

  <script>
    const togglePassword = document.getElementById('togglePassword');
    const passwordField = document.getElementById('password');

    if (togglePassword && passwordField) {
        togglePassword.addEventListener('click', () => {
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            togglePassword.classList.toggle('fa-eye');
            togglePassword.classList.toggle('fa-eye-slash');
        });
    }
  </script>

</body>
</html>