<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EportKhelegaIndia</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Russo+One&display=swap" rel="stylesheet">

    <!-- Custom CSS -->
     <link rel="stylesheet" href="css/style.css">
</head>
<body class="has-fixed-navbar-only"> <!-- Add 'has-fixed-ticker-and-navbar' if both are fixed -->

    <!-- Ticker Section -->
    <div class="ticker-wrap">
    <div class="ticker-move">
        <?php
        include 'db.php';
        $result = $conn->query("SELECT * FROM tickers ORDER BY created_at DESC");
        while ($row = $result->fetch_assoc()) {
            echo '<span><i class="' . htmlspecialchars($row['icon']) . '"></i> ' . htmlspecialchars($row['message']) . ' - <a href="' . htmlspecialchars($row['link']) . '">Click Here</a></span>';
        }
        ?>
    </div>
</div>


    <!-- Navbar -->
    <nav id="mainNavbar" class="navbar navbar-expand-lg fixed-top py-3">
        <div class="container">
            <a class="navbar-brand" href="#hero">
                <img src="Assets/logo.png" alt="eSportKhelegaIndia Logo"> <!-- Example Logo -->
                <span>Esportkhelegaindia</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#hero">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#winners">Winners</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#blog">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center nav-buttons-flex">
                    <a href="register.php" class="btn btn-register me-lg-2">Register</a> <!-- me-lg-2 for margin on large screens only -->
                    <a href="login.php" class="btn btn-login">Login</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <header id="hero" class="section">
        <div class="container">
            <h1 class="display-3">Forge Your Legacy. Dominate The Arena.</h1>
            <p class="lead-subtext">Step into the heart of competitive gaming. Join thrilling tournaments, showcase your skills, and rise as a champion on India's premier esports platform.</p>
            <a href="#contact" class="btn btn-lg btn-hero">Claim Your Spot</a>
        </div>
    </header>

    <!-- Winners Section (No changes from previous version) -->
   <section id="winners" class="section">
  <div class="container">
    <h2 class="section-title">Our Champions</h2>
    <div class="row justify-content-center">

      <?php
      include 'db.php';  // Adjust path if needed

      $result = $conn->query("SELECT * FROM winners ORDER BY id DESC");

      if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
          ?>
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="winner-card">
              <img src="<?= htmlspecialchars($row['image_url']) ?>" alt="<?= htmlspecialchars($row['name']) ?>">
              <h5><?= htmlspecialchars($row['name']) ?> "<?= htmlspecialchars($row['nickname']) ?>"</h5>
              <p>Winner - <?= htmlspecialchars($row['game']) ?></p>
            </div>
          </div>
          <?php
        }
      } else {
        echo "<p>No winners found.</p>";
      }
      ?>

    </div>
  </div>
</section>


    <!-- Blog Section -->
    <section id="blog" class="section">
    <div class="container">
        <h2 class="section-title">Latest From Our Blog</h2>
        <div class="row">
            <?php
            include 'db.php';
            $result = $conn->query("SELECT * FROM blogs ORDER BY created_at DESC LIMIT 3");
            while ($row = $result->fetch_assoc()) {
            ?>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card blog-card">
                    <img src="<?= htmlspecialchars($row['image_url']) ?>" class="card-img-top" alt="Blog Image">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($row['title']) ?></h5>
                        <p class="card-text"><?= htmlspecialchars(substr($row['content'], 0, 120)) ?>...</p>
                        <a href="blog-detail.php?id=<?= $row['id'] ?>" class="btn btn-read-more">Read More</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</section>


    <!-- Contact Section  -->
    <section id="contact" class="section">
        <div class="container">
            <h2 class="section-title">Get In Touch</h2>
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <form id="contactFormReal">
                        <div class="mb-3">
                            <label for="contactName" class="form-label">Your Name</label>
                            <input type="text" class="form-control" id="contactName" placeholder="John Doe" required>
                        </div>
                        <div class="mb-3">
                            <label for="contactEmail" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="contactEmail" placeholder="name@example.com" required>
                        </div>
                        <div class="mb-3">
                            <label for="contactMessage" class="form-label">Your Message</label>
                            <textarea class="form-control" id="contactMessage" rows="5" placeholder="Let us know how we can help!" required></textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-lg btn-submit-contact">Send Message</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer  -->
    <footer>
        <div class="container">
            <div class="social-icons mb-3">
                <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="#" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="#" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                <a href="#" aria-label="Twitter"><i class="fab fa-x-twitter"></i></a>
            </div>
            <p>© <span id="currentYear"></span> eSportKhelegaIndia. All Rights Reserved. Designed with <i class="fas fa-heart"></i>.</p>
        </div>
    </footer>


    <!-- Bootstrap JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <!-- Custom JS -->
      <script src="js\script.js"></script>

    <script>
       
    </script>

</body>
</html>