<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';
include 'db.php'; // Ensure this path is correct

$message_to_display = ""; // For user feedback on the page

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message_to_display = "<div class='alert alert-danger mt-3'>Please enter a valid email address.</div>";
    } else {
        // Check if the email exists in the database
        $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        if (!$check_stmt) {
            error_log("Prepare failed (check_stmt): (" . $conn->errno . ") " . $conn->error);
            $message_to_display = "<div class='alert alert-danger mt-3'>An error occurred. Please try again later.</div>";
        } else {
            $check_stmt->bind_param("s", $email);
            $check_stmt->execute();
            $check_stmt->store_result();

            if ($check_stmt->num_rows > 0) {
                $otp = rand(100000, 999999);
                $expiry = date("Y-m-d H:i:s", strtotime("+10 minutes"));

                $update_stmt = $conn->prepare("UPDATE users SET otp_code = ?, otp_expiry = ? WHERE email = ?");
                if (!$update_stmt) {
                    error_log("Prepare failed (update_stmt): (" . $conn->errno . ") " . $conn->error);
                    $message_to_display = "<div class='alert alert-danger mt-3'>An error occurred while updating OTP. Please try again.</div>";
                } else {
                    $update_stmt->bind_param("sss", $otp, $expiry, $email);

                    if ($update_stmt->execute()) {
                        $mail = new PHPMailer(true);
                        try {
                            //Server settings
                            $mail->isSMTP();
                            $mail->Host       = 'smtp.gmail.com'; // Your SMTP host
                            $mail->SMTPAuth   = true;
                            $mail->Username   = 'esportkhelegaindia@gmail.com'; // Your SMTP username
                            $mail->Password   = 'jcbbkzmohdzwvodt'; // Your SMTP app password
                            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                            $mail->Port       = 587;

                            //Recipients
                            $mail->setFrom('esportkhelegaindia@gmail.com', 'Esport Khelega India Support');
                            $mail->addAddress($email);

                            // Content
                            $mail->isHTML(true);
                            $mail->Subject = 'Your Password Reset OTP - Esport Khelega India';
                            $mail->Body    = "
                            <div style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
                                <h2 style='color: #FF9933;'>Password Reset Request</h2>
                                <p>Dear Player,</p>
                                <p>We received a request to reset the password for your Esport Khelega India account associated with this email address.</p>
                                <p>Your One-Time Password (OTP) is: <strong style='font-size: 1.2em; color: #138808;'>$otp</strong></p>
                                <p>This OTP is valid for the next <strong>10 minutes</strong>. Please do not share this code with anyone.</p>
                                <p>If you did not request a password reset, please ignore this email or contact our support team if you have concerns.</p>
                                <hr style='border: 0; border-top: 1px solid #eee;'>
                                <p>Thanks & Regards,<br>
                                <strong>The Esport Khelega India Team</strong></p>
                                <p style='font-size: 0.8em; color: #777;'>This is an automated message, please do not reply directly to this email.</p>
                            </div>";
                            $mail->AltBody = "Dear Player,\n\nYour One-Time Password (OTP) for password reset is: $otp\nThis OTP is valid for the next 10 minutes. Please do not share this code with anyone.\n\nIf you did not request a password reset, please ignore this email.\n\nThanks & Regards,\nThe Esport Khelega India Team";

                            $mail->send();
                            $message_to_display = "<div class='alert alert-success mt-3'>An OTP has been sent to your email address. It will expire in 10 minutes. Redirecting...</div>";
                            echo "<script>
                                setTimeout(function() {
                                    window.location.href = 'reset_password.php?email=" . urlencode($email) . "';
                                }, 3000);
                            </script>";
                        } catch (Exception $e) {
                            error_log("Mailer Error: " . $mail->ErrorInfo);
                            $message_to_display = "<div class='alert alert-danger mt-3'>OTP could not be sent. Please try again later. Mailer Error: {$mail->ErrorInfo}</div>";
                        }
                        $update_stmt->close();
                    } else {
                        error_log("Execute failed (update_stmt): (" . $update_stmt->errno . ") " . $update_stmt->error);
                        $message_to_display = "<div class='alert alert-danger mt-3'>Failed to process your request. Please try again.</div>";
                    }
                }
            } else {
                $message_to_display = "<div class='alert alert-warning mt-3'>This email address is not registered with us. Please check and try again.</div>";
            }
            $check_stmt->close();
        }
    }
    if (isset($conn)) { // Check if connection exists before closing
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Forgot Password - Tiranga Theme</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    :root {
      --saffron: #FF9933;
      --white: #FFFFFF;
      --green: #138808;
      --navy-blue: #0033A0;

      --dark-bg: #121212;
      --container-bg: #1E1E1E;
      --input-bg: #2C2C2C;
      --input-border: #4A4A4A;
      --input-border-focus: var(--green);

      --light-text: #E0E0E0;
      --dim-text: #888888;
      /* --label-active-color: var(--saffron); */ /* Not used here, but kept for consistency if forms expand */

      /* RGB for shadows */
      --saffron-rgb: 255, 153, 51;
      --green-rgb: 19, 136, 8;
    }

    /* --- Global Box Sizing --- */
    html {
        box-sizing: border-box;
    }
    *, *::before, *::after {
        box-sizing: inherit;
    }
    /* --- End Global Box Sizing --- */


    body {
      background-color: var(--dark-bg);
      color: var(--light-text);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex; /* For centering the wrapper */
      justify-content: center; /* Horizontal centering */
      align-items: center; /* Vertical centering */
      min-height: 100vh; /* Ensure body takes at least full viewport height */
      margin: 0; /* Remove default browser margin */
      /* Padding is removed from body, will be handled by wrapper for edge spacing */
    }

    .forgot-password-wrapper {
      width: 100%; /* Takes full available width from parent (body) */
      max-width: 420px; /* Maximum width for the form container */
      padding: 0 15px; /* Adds 15px space on left/right INSIDE the wrapper.
                          This prevents the box from touching screen edges on small devices. */
    }

    .forgot-password-box {
      background: var(--container-bg);
      padding: 35px 30px; /* Internal padding for form elements */
      border-radius: 12px;
      box-shadow: 0 5px 25px rgba(var(--saffron-rgb), 0.15);
      border-top: 4px solid var(--saffron);
      animation: fadeInForm 0.7s ease-out;
      width: 100%; /* Makes the box fill the (padded) wrapper */
    }

    @keyframes fadeInForm {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .forgot-password-box h3 {
      text-align: center;
      color: var(--saffron);
      margin-top: 0; /* Remove top margin if it's the first element */
      margin-bottom: 30px;
      font-weight: 700;
      letter-spacing: 0.5px;
    }

    .form-group {
        margin-bottom: 25px; /* Increased spacing for single input form */
    }

    .form-control-custom {
      width: 100%;
      padding: 12px 15px;
      background-color: var(--input-bg);
      border: 1px solid var(--input-border);
      color: var(--light-text);
      border-radius: 6px;
      font-size: 16px;
      transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }
    .form-control-custom::placeholder {
      color: var(--dim-text);
    }
    .form-control-custom:focus {
      border-color: var(--input-border-focus);
      box-shadow: 0 0 8px rgba(var(--green-rgb), 0.3);
      outline: none;
    }

    .btn-custom-primary {
      background-color: var(--green);
      color: var(--white);
      border: none;
      font-weight: bold;
      padding: 12px 15px;
      width: 100%;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease, box-shadow 0.3s ease, transform 0.2s ease;
    }

    .btn-custom-primary:hover {
      background-color: var(--saffron);
      color: var(--dark-bg);
      box-shadow: 0 0 12px rgba(var(--saffron-rgb), 0.4);
      transform: translateY(-2px);
    }

    .alert {
        padding: 12px 15px; /* Slightly more padding for alerts */
        margin-top: 20px; /* Add margin-top to separate from heading if it's the first element after */
        margin-bottom: 20px;
        border: 1px solid transparent;
        border-radius: 6px; /* Consistent border-radius */
        font-size: 0.95em;
        text-align: center; /* Center alert text */
    }
    /* Ensure alerts take full width and have no top margin if they are the first child after h3 */
    .forgot-password-box > .alert:first-of-type {
        margin-top: 0;
    }
    .alert-success {
        color: #0f5132;
        background-color: #d1e7dd;
        border-color: #badbcc;
    }
    .alert-danger {
        color: #842029;
        background-color: #f8d7da;
        border-color: #f5c2c7;
    }
    .alert-warning {
        color: #664d03;
        background-color: #fff3cd;
        border-color: #ffecb5;
    }

    /* --- Media Query for Smaller Screens --- */
    @media (max-width: 480px) { /* Common breakpoint for small phones */
      .forgot-password-box {
        padding: 30px 20px; /* Reduce internal padding slightly */
      }
      .forgot-password-box h3 {
          font-size: 1.6rem; /* Adjust heading size */
          margin-bottom: 25px;
      }
      .form-control-custom, .btn-custom-primary {
          font-size: 15px; /* Slightly smaller font for inputs/buttons */
          padding: 11px 14px; /* Adjust padding for inputs/buttons */
      }
      .alert {
          font-size: 0.9em;
          padding: 10px;
      }
    }
    /* You can add more breakpoints if needed, e.g., max-width: 768px for tablets */

  </style>
</head>
<body>

<div class="forgot-password-wrapper">
  <div class="forgot-password-box">
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <h3>Forgot Password</h3>
      <?php if (!empty($message_to_display)) echo $message_to_display; ?>
      <div class="form-group">
        <input type="email" name="email" placeholder="Enter your registered email" required class="form-control-custom">
      </div>
      <button type="submit" class="btn-custom-primary">Send OTP</button>
    </form>
  </div>
</div>

</body>
</html>