<?php
include 'db.php';

if (!isset($_GET['id'])) {
    echo "No blog ID provided. <a href='index.php#blog'>Go back</a>";
    exit;
}

$id = (int)$_GET['id']; // Good practice to cast to int
$stmt = $conn->prepare("SELECT * FROM blogs WHERE id = ?"); // Assuming 'id', 'title', 'content', 'image_url', 'image_caption', 'author', 'created_at' exist
if (!$stmt) {
    error_log("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    echo "Error preparing statement. <a href='index.php#blog'>Go back</a>";
    exit;
}
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$blog = $result->fetch_assoc();
$stmt->close();

if (!$blog) {
    echo "Blog not found! <a href='index.php#blog'>Go back</a>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= htmlspecialchars($blog['title']) ?> - Our Blog</title>
  <style>
    :root {
      --saffron: #FF9933;
      --white: #FFFFFF;
      --green: #138808;
      --navy-blue: #0033A0;
      --dark-bg: #0F0F0F; /* Even darker for more pop */
      --container-bg: #1B1B1B;
      --light-text: #EAEAEA;
      --meta-text: #999999;
      --border-color: #333333;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Roboto', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: var(--dark-bg);
      color: var(--light-text);
      line-height: 1.7;
      padding: 0; /* Remove body padding, handle spacing with article container */
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .blog-article-wrapper { /* New wrapper for full-width elements if needed */
        width: 100%;
    }

    .blog-hero-image-container {
        width: 100%; /* Full width of its parent */
        max-height: 550px; /* Adjust as desired */
        overflow: hidden;
        position: relative; /* For potential overlay elements or captions */
        background-color: #222; /* Fallback if image is missing */
    }

    .blog-hero-image-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
        transition: transform 0.5s ease-out, filter 0.3s ease;
    }
    .blog-hero-image-container:hover img {
        transform: scale(1.03); /* Subtle zoom on hover */
        filter: brightness(0.9);
    }

    .image-caption {
        background-color: rgba(0, 0, 0, 0.6);
        color: var(--meta-text);
        padding: 8px 15px;
        font-size: 0.85rem;
        text-align: center;
        width: 100%;
        position: absolute; /* Position over the image */
        bottom: 0;
        left: 0;
        box-sizing: border-box;
    }
     /* If you prefer caption below image */
    .image-caption-below {
        padding: 10px 0;
        text-align: center;
        font-size: 0.9em;
        color: var(--meta-text);
        background-color: var(--container-bg); /* Match article bg */
        border-bottom: 1px solid var(--border-color);
    }


    .blog-post-container { /* This was your original .container */
      max-width: 850px;
      width: 100%;
      margin: 0 auto; /* Centered */
      background: var(--container-bg);
      /* Removed top border - hero image serves this purpose */
      animation: fadeIn 0.8s ease-out;
    }

    .blog-content-padding { /* Added for padding inside the container, separate from image */
        padding: 30px 40px;
    }


    .blog-header {
        margin-bottom: 25px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--border-color);
    }

    .blog-title {
      color: var(--saffron);
      font-size: 2.8rem;
      font-weight: 700;
      line-height: 1.2;
      margin-bottom: 10px;
      text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
    }

    .blog-meta {
      font-size: 0.9rem;
      color: var(--meta-text);
      margin-bottom: 0; /* Moved margin to .blog-header */
    }
    .blog-meta span { margin-right: 15px; }
    .blog-meta time { font-style: italic; }
    .blog-meta a {
        color: var(--meta-text);
        text-decoration: none;
        transition: color 0.3s ease;
    }
    .blog-meta a:hover {
        color: var(--saffron);
    }

    .blog-article-content {
      font-size: 1.15rem; /* Slightly larger for readability */
      color: var(--light-text);
    }
    .blog-article-content p {
      margin-bottom: 1.8em;
    }
    .blog-article-content strong {
      color: var(--saffron);
      font-weight: 600;
    }
    .blog-article-content a {
      color: var(--green);
      text-decoration: none;
      border-bottom: 2px dotted var(--green);
      transition: color 0.3s ease, border-color 0.3s ease;
    }
    .blog-article-content a:hover {
      color: var(--saffron);
      border-bottom-color: var(--saffron);
      border-bottom-style: solid;
    }
    .blog-article-content ul, .blog-article-content ol {
      margin-left: 30px;
      margin-bottom: 1.8em;
    }
    .blog-article-content li {
      margin-bottom: 0.6em;
    }
    .blog-article-content blockquote {
        border-left: 4px solid var(--saffron);
        padding-left: 20px;
        margin: 2em 0;
        font-style: italic;
        color: var(--meta-text);
        font-size: 1.1rem;
    }
    .blog-article-content img.inline-image { /* For images within content */
        max-width: 100%;
        height: auto;
        border-radius: 8px;
        margin: 1.5em 0;
        display: block;
        border: 1px solid var(--border-color);
    }


    .blog-footer {
        margin-top: 40px;
        padding-top: 20px;
        border-top: 1px solid var(--border-color);
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 20px;
    }
    .social-share {
        display: flex;
        gap: 15px;
    }
    .social-share a {
        display: inline-block;
        padding: 8px 15px;
        color: var(--light-text);
        background-color: #2a2a2a;
        border-radius: 5px;
        text-decoration: none;
        font-size: 0.9rem;
        border: 1px solid var(--border-color);
        transition: background-color 0.3s ease, color 0.3s ease, transform 0.2s ease;
    }
    .social-share a:hover {
        background-color: var(--saffron);
        color: var(--dark-bg);
        transform: translateY(-2px);
    }
    /* Specific social colors on hover (example) */
    .social-share a.twitter:hover { background-color: #1DA1F2; color: var(--white); }
    .social-share a.facebook:hover { background-color: #1877F2; color: var(--white); }
    .social-share a.linkedin:hover { background-color: #0A66C2; color: var(--white); }


    a.back-to-blog-link {
      display: inline-block;
      padding: 12px 30px;
      background-color: transparent;
      color: var(--saffron);
      font-weight: 600;
      text-decoration: none;
      border-radius: 50px; /* Pill shape */
      border: 2px solid var(--saffron);
      transition: all 0.3s ease;
      font-size: 1rem;
    }
    a.back-to-blog-link:hover,
    a.back-to-blog-link:focus {
      background-color: var(--saffron);
      color: var(--dark-bg);
      box-shadow: 0 0 15px rgba(255, 153, 51, 0.5);
    }
    a.back-to-blog-link .arrow {
      margin-right: 10px;
      font-weight: bold;
      transition: transform 0.3s ease;
    }
    a.back-to-blog-link:hover .arrow {
        transform: translateX(-5px);
    }


    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* Responsive Adjustments */
    @media (max-width: 900px) { /* When container might touch edges */
        .blog-hero-image-container {
            border-radius: 0; /* No radius if it's edge to edge */
        }
        .blog-post-container {
            margin: 0; /* No margin if full width */
            border-radius: 0;
        }
    }

    @media (max-width: 768px) {
      .blog-content-padding {
          padding: 25px 20px;
      }
      .blog-title {
        font-size: 2.2rem;
      }
      .blog-article-content {
        font-size: 1.05rem;
      }
      .blog-hero-image-container {
        max-height: 400px;
      }
      a.back-to-blog-link {
        padding: 10px 25px;
        font-size: 0.95rem;
      }
    }

    @media (max-width: 480px) {
      .blog-content-padding {
          padding: 20px 15px;
      }
      .blog-title {
        font-size: 1.8rem;
      }
      .blog-article-content {
        font-size: 1rem;
      }
      .blog-hero-image-container {
        max-height: 300px;
      }
      .blog-meta {
          font-size: 0.8rem;
      }
      .social-share {
          flex-direction: column; /* Stack share buttons */
          width: 100%;
      }
      .social-share a {
          text-align: center;
      }
      a.back-to-blog-link {
        width: calc(100% - 30px); /* Full width with padding */
        margin-left: 15px;
        margin-right: 15px;
        box-sizing: border-box;
        text-align: center;
      }
    }
  </style>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>

<div class="blog-article-wrapper">

    <?php if (!empty($blog['image_url'])): ?>
    <div class="blog-hero-image-container">
        <img src="<?= htmlspecialchars($blog['image_url']) ?>" alt="<?= htmlspecialchars($blog['title']) ?> hero image" />
        <?php if (!empty($blog['image_caption'])): // Assuming you have an 'image_caption' field ?>
            <div class="image-caption"><?= htmlspecialchars($blog['image_caption']) ?></div>
        <?php endif; ?>
    </div>
    <?php /* If you prefer caption below:
    if (!empty($blog['image_caption'])): ?>
        <div class="image-caption-below"><?= htmlspecialchars($blog['image_caption']) ?></div>
    <?php endif; */?>
    <?php endif; ?>

    <article class="blog-post-container">
        <div class="blog-content-padding">
            <header class="blog-header">
                <h1 class="blog-title"><?= htmlspecialchars($blog['title']) ?></h1>
                <div class="blog-meta">
                    <?php if (!empty($blog['author'])): // Assuming 'author' field ?>
                        <span>By <a href="#author-profile-link"><?= htmlspecialchars($blog['author']) ?></a></span>
                    <?php endif; ?>
                    <?php if (!empty($blog['created_at'])): // Assuming 'created_at' field ?>
                        <span>Posted on <time datetime="<?= date('Y-m-d', strtotime($blog['created_at'])) ?>"><?= date('F j, Y', strtotime($blog['created_at'])) ?></time></span>
                    <?php endif; ?>
                    <!-- Add category or tags here if available -->
                </div>
            </header>

            <section class="blog-article-content">
                <?= nl2br(htmlspecialchars($blog['content'])) // For simple text. Consider a Markdown parser for richer content. ?>
                <!-- Example of an inline image if your content supports it: -->
                <!-- <img src="path/to/another-image.jpg" alt="Inline image" class="inline-image"> -->
                <!-- Example of a blockquote: -->
                <!-- <blockquote>This is an important quote that stands out.</blockquote> -->
            </section>

            <footer class="blog-footer">
                <div class="social-share">
                    <!-- Replace # with actual share links (often needs JS for dynamic URLs) -->
                    <a href="#" class="twitter" title="Share on Twitter">Twitter</a>
                    <a href="#" class="facebook" title="Share on Facebook">Facebook</a>
                    <a href="#" class="linkedin" title="Share on LinkedIn">LinkedIn</a>
                </div>
                <a href="index.php#blog" class="back-to-blog-link"><span class="arrow">←</span> Back to All Blogs</a>
            </footer>
        </div>
    </article>

</div>

</body>
</html>