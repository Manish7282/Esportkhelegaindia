<?php
session_start();
// Make sure to include your database connection file
// Adjust the path if your db.php is in a different location relative to wallet.php
// e.g., if wallet.php is in the root with profile.php, and db.php is one level up:
// include '../db.php';
// If db.php is in the same directory:
include 'db.php';


// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User'; // For navbar consistency
$wallet_balance = 0.00; // Default balance

// Fetch wallet balance from the database
// Ensure $conn is your mysqli connection object from db.php
if (isset($conn) && $conn) {
    $stmt = $conn->prepare("SELECT wallet_balance FROM users WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $wallet_balance = $row['wallet_balance'];
        } else {
            // User not found or no wallet balance, though this shouldn't happen if user_id is valid
            // Log error or handle as appropriate
             error_log("User ID {$user_id} not found in users table for wallet balance.");
        }
        $stmt->close();
    } else {
        // Handle DB error (e.g., log it, show generic message)
        error_log("Failed to prepare statement for wallet balance: " . $conn->error);
        // You might want to set a user-facing error message here too
    }
} else {
    // Handle DB connection error
    error_log("Database connection not available in wallet.php. Check db.php include and connection.");
    // Set a user-facing error message or redirect
}

// Determine current page for active link styling
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wallet - <?php echo htmlspecialchars($user_name); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* PASTE ALL CSS FROM YOUR profile.php HERE */
        /* For brevity, I'm not repeating all of it, but you should copy it. */
        /* Start of copied CSS from profile.php */
        :root {
            --navbar-orange: #F7931E;
            --link-green: #138808;
            --text-white: #FFFFFF;
            --text-dark: #333333;
            --page-bg-white: #FFFFFF;
            --dropdown-bg: #FFFFFF;
            --dropdown-hover-bg: #f0f0f0;
            --navbar-height: 60px;
        }

        body {
            background: var(--page-bg-white);
            color: var(--text-dark);
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding-top: var(--navbar-height);
        }

        .navbar {
            background: var(--navbar-orange);
            padding: 0 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--text-white);
            height: var(--navbar-height);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            box-sizing: border-box;
            z-index: 1000;
            box-shadow: 0 2px 5px rgba(0,0,0,0.15);
        }

        .navbar-left, .navbar-right { display: flex; align-items: center; }
        .navbar-center { display: flex; justify-content: center; flex-grow: 1; }
        .logo { height: 40px; margin-right: 10px; transition: transform 0.3s ease; }
        .logo:hover { transform: scale(1.05); }
        .site-name { font-size: 1.5em; font-weight: bold; color: var(--text-white); letter-spacing: 0.5px; }
        .nav-links a { color: var(--text-white); text-decoration: none; margin: 0 15px; font-weight: bold; font-size: 1em; padding: 5px 0; transition: color 0.3s, opacity 0.3s; }
        .nav-links a.nav-link-home, .nav-links a.active-link { color: var(--link-green); }
        .nav-links a.nav-link-home:hover, .nav-links a.active-link:hover { opacity: 0.8; }
        .nav-links a:not(.nav-link-home):not(.active-link):hover { opacity: 0.8; }
        .user-profile { position: relative; display: flex; align-items: center; cursor: pointer; color: var(--text-white); }
        .user-icon { font-size: 1.8em; margin-right: 8px; color: var(--text-white); }
        .user-profile span { font-weight: bold; }
        .user-profile .fa-caret-down { color: var(--text-white); }
        .dropdown { display: none; position: absolute; right: 0; top: calc(100% + 10px); background-color: var(--dropdown-bg); border: 1px solid #ccc; min-width: 180px; box-shadow: 0 8px 16px rgba(0,0,0,0.2); z-index: 10; border-radius: 4px; opacity: 0; transform: translateY(-10px); transition: opacity 0.2s ease, transform 0.2s ease; }
        .dropdown.active { display: block; opacity: 1; transform: translateY(0); }
        .dropdown a { color: var(--text-dark); padding: 12px 16px; text-decoration: none; display: flex; align-items: center; font-weight: normal; transition: background-color 0.2s ease; }
        .dropdown a i { margin-right: 10px; width: 20px; text-align: center; color: var(--text-dark); }
        .dropdown a:hover { background-color: var(--dropdown-hover-bg); }
        .hamburger { display: none; font-size: 1.8em; cursor: pointer; color: var(--text-white); }
        .content { padding: 30px; max-width: 960px; margin: 0 auto; animation: fadeInSlideUp 0.8s ease-out forwards; }
        .content h1 { animation: slideInFromLeft 0.7s ease-out 0.2s forwards; opacity: 0; }
        .content p { animation: slideInFromLeft 0.7s ease-out 0.4s forwards; opacity: 0; }
        @keyframes fadeInSlideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes slideInFromLeft { from { opacity: 0; transform: translateX(-30px); } to { opacity: 1; transform: translateX(0); } }
        @media (max-width: 992px) { .site-name { font-size: 1.3em; } .nav-links a { margin: 0 10px; } }
        @media (max-width: 768px) { .navbar-center { position: absolute; top: var(--navbar-height); left: 0; width: 100%; background: var(--navbar-orange); flex-direction: column; align-items: center; padding: 0; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-height: 0; overflow: hidden; transition: max-height 0.4s ease-in-out, padding 0.4s ease-in-out; } .navbar-center.active { max-height: 350px; padding: 10px 0; } .nav-links a { margin: 8px 0; padding: 12px 20px; width: 90%; text-align: center; box-sizing: border-box; border-radius: 4px; color: var(--text-white); } .nav-links a.nav-link-home, .nav-links a.active-link { background-color: rgba(0,0,0,0.1); color: var(--link-green); } .nav-links a:not(.nav-link-home):not(.active-link):hover { background-color: rgba(255,255,255,0.15); opacity: 1; } .hamburger { display: block; margin-left: 15px; } }
        @media (max-width: 480px) { .site-name { font-size: 1.1em; } .user-profile > span > span:not(.fa-caret-down) { display: none; } .user-icon { margin-right: 5px; } }
        /* End of copied CSS */

        /* Additional styles specific to wallet page */
        .wallet-info-card {
            background-color: #fff; /* Or var(--form-bg) if you defined it */
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            margin-top: 20px;
        }
        .wallet-balance-label {
            font-size: 1.2em;
            color: var(--text-dark);
            margin-bottom: 5px;
        }
        .wallet-balance-amount {
            font-size: 3em; /* Make it prominent */
            font-weight: bold;
            color: var(--link-green); /* Green for balance */
            margin: 10px 0 20px 0;
            letter-spacing: 1px;
        }
        .wallet-actions a {
            display: inline-block;
            margin: 10px;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .wallet-actions .add-money {
            background-color: var(--link-green);
            color: var(--text-white);
        }
        .wallet-actions .add-money:hover {
            background-color: var(--button-green-darker); /* Define if not already */
            transform: translateY(-2px);
        }
        .wallet-actions .transaction-history {
            background-color: var(--navbar-orange);
            color: var(--text-white);
        }
        .wallet-actions .transaction-history:hover {
            background-color: #e08010; /* Darker orange */
            transform: translateY(-2px);
        }

    </style>
</head>
<body>

<!-- Navbar - MAKE SURE THIS IS IDENTICAL TO YOUR profile.php NAVBAR -->
<div class="navbar">
    <div class="navbar-left">
        <img src="Assets/logo.png" alt="My Logo" class="logo"> <!-- Replace with your actual logo -->
        <span class="site-name">EsportKheloIndia</span>
    </div>

    <div class="navbar-center nav-links" id="navLinks">
        <a href="home.php" class="<?php echo ($current_page == 'home.php' || $current_page == 'index.php') ? 'active-link' : 'nav-link-home'; ?>">Home</a>
        <a href="winners.php" class="<?php echo ($current_page == 'winners.php') ? 'active-link' : ''; ?>">Winners</a>
        <a href="blog.php" class="<?php echo ($current_page == 'blog.php') ? 'active-link' : ''; ?>">Blog</a>
        <a href="contact.php" class="<?php echo ($current_page == 'contact.php') ? 'active-link' : ''; ?>">Contact</a>
    </div>

    <div class="navbar-right">
        <div class="user-profile" id="userProfileToggle">
            <i class="fas fa-user-circle user-icon"></i>
            <span><span>Hello, <?php echo htmlspecialchars($user_name); ?></span> <i class="fas fa-caret-down" style="font-size:0.8em;"></i></span>
            <div class="dropdown" id="userDropdown">
                <a href="profile.php"><i class="fas fa-user-edit"></i> My Profile</a>
                <a href="wallet.php"><i class="fas fa-wallet"></i> Wallet</a> <!-- Active page if on wallet.php -->
                <a href="my_winning.php"><i class="fas fa-trophy"></i> My Winnings</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
        <div class="hamburger" id="hamburgerMenu">
            <i class="fas fa-bars"></i>
        </div>
    </div>
</div>

<!-- Page Content for Wallet -->
<div class="content">
    <h1>My Wallet</h1>

    <div class="wallet-info-card">
        <div class="wallet-balance-label">Your Current Balance</div>
        <div class="wallet-balance-amount">
            ₹<?php echo htmlspecialchars(number_format($wallet_balance, 2)); ?>
        </div>
        <p>Manage your funds, view transactions, or add more to your wallet.</p>
        <div class="wallet-actions">
            <a href="add_money.php" class="add-money"><i class="fas fa-plus-circle"></i> Add Money</a>
            <a href="transaction_history.php" class="transaction-history"><i class="fas fa-history"></i> Transaction History</a>
            <!-- You could add a "Withdraw Funds" button if applicable -->
            <!-- <a href="withdraw.php" class="transaction-history" style="background-color: #cc0000;">Withdraw Funds</a> -->
        </div>
    </div>

    <!-- You could also list a few recent transactions here if desired -->
    <!-- Example:
    <div class="recent-transactions" style="margin-top: 30px;">
        <h3>Recent Transactions</h3>
        <ul>
            <li>Transaction 1 - Date - Amount - Type</li>
            <li>Transaction 2 - Date - Amount - Type</li>
        </ul>
    </div>
    -->
</div>

<!-- JavaScript for Navbar - MAKE SURE THIS IS IDENTICAL TO YOUR profile.php SCRIPT -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const userProfileToggle = document.getElementById('userProfileToggle');
        const userDropdown = document.getElementById('userDropdown');
        const hamburgerMenu = document.getElementById('hamburgerMenu');
        const navLinks = document.getElementById('navLinks');

        if (userProfileToggle && userDropdown) {
            userProfileToggle.addEventListener('click', function(event) {
                event.stopPropagation();
                userDropdown.classList.toggle('active');
            });
        }

        if (hamburgerMenu && navLinks) {
            hamburgerMenu.addEventListener('click', function(event) {
                event.stopPropagation();
                navLinks.classList.toggle('active');
                const icon = hamburgerMenu.querySelector('i');
                if (navLinks.classList.contains('active')) {
                    icon.classList.remove('fa-bars');
                    icon.classList.add('fa-times');
                } else {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
            });
        }

        document.addEventListener('click', function(event) {
            if (userDropdown && userDropdown.classList.contains('active') && !userProfileToggle.contains(event.target) && !userDropdown.contains(event.target)) {
                userDropdown.classList.remove('active');
            }
            if (navLinks && navLinks.classList.contains('active') && !navLinks.contains(event.target) && !hamburgerMenu.contains(event.target) && !event.target.closest('.navbar')) {
                 navLinks.classList.remove('active');
                 const icon = hamburgerMenu.querySelector('i');
                 icon.classList.remove('fa-times');
                 icon.classList.add('fa-bars');
            }
        });
    });
</script>

</body>
</html>