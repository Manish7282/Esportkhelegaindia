 document.addEventListener('DOMContentLoaded', function () {
            const mainNavbar = document.getElementById('mainNavbar');
            const navLinks = document.querySelectorAll('#navbarNav .nav-link');
            const sections = document.querySelectorAll('header.section, section.section'); // Include header
            const tickerWrap = document.querySelector('.ticker-wrap');

            // Adjust body padding based on fixed elements
            function adjustBodyPadding() {
                let totalFixedTopHeight = 0;
                if (tickerWrap && getComputedStyle(tickerWrap).position === 'fixed') {
                    totalFixedTopHeight += tickerWrap.offsetHeight;
                }
                if (mainNavbar && mainNavbar.classList.contains('fixed-top')) {
                    totalFixedTopHeight += mainNavbar.offsetHeight;
                }
                document.body.style.paddingTop = totalFixedTopHeight + 'px';
            }

            // Call on load and resize
            adjustBodyPadding();
            window.addEventListener('resize', adjustBodyPadding);


            function changeNavOnScroll() {
                let current = 'hero';
                const navbarHeight = mainNavbar ? mainNavbar.offsetHeight : 70;
                const tickerHeight = (tickerWrap && getComputedStyle(tickerWrap).position !== 'fixed') ? tickerWrap.offsetHeight : 0; // Only add if not fixed and affecting flow

                sections.forEach(section => {
                    const sectionTop = section.offsetTop - tickerHeight; // Account for ticker if it's in document flow
                    if (pageYOffset >= sectionTop - navbarHeight - 50) {
                        current = section.getAttribute('id');
                    }
                });

                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href').substring(1) === current) {
                        link.classList.add('active');
                    }
                });

                if (mainNavbar) { // Navbar shrink effect
                    if (window.scrollY > (tickerHeight + 50) ) { // Consider ticker height for shrink trigger
                        mainNavbar.classList.add('navbar-scrolled');
                    } else {
                        mainNavbar.classList.remove('navbar-scrolled');
                    }
                }
            }

            window.addEventListener('scroll', changeNavOnScroll);
            changeNavOnScroll(); // Call on load

            navLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    if (this.hash !== "") {
                        const hash = this.hash;
                        const targetElement = document.querySelector(hash);
                        if (targetElement) {
                            e.preventDefault();
                            const navbarHeight = mainNavbar ? mainNavbar.offsetHeight : 70;
                            // Ticker height needs to be considered if it's part of the flow below fixed navbar
                            const tickerCurrentHeight = (tickerWrap && getComputedStyle(tickerWrap).position !== 'fixed') ? tickerWrap.offsetHeight : 0;

                            let elementPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
                            let offsetPosition = elementPosition - navbarHeight - tickerCurrentHeight;

                            window.scrollTo({
                                top: offsetPosition,
                                behavior: 'smooth'
                            });

                            navLinks.forEach(nav => nav.classList.remove('active'));
                            this.classList.add('active');

                            const navbarCollapse = document.getElementById('navbarNav');
                            if (navbarCollapse.classList.contains('show')) {
                                const toggler = document.querySelector('.navbar-toggler');
                                if (toggler) {
                                    toggler.click();
                                }
                            }
                        }
                    }
                });
            });

            const heroSection = document.getElementById('hero');
            if (heroSection) {
                const esportsImages = [
                    'https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80',
                    'https://images.unsplash.com/photo-1609810099010-4226795683d7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80',
                    'https://images.unsplash.com/photo-1593305841991-05c297ba4575?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1657&q=80',
                    'https://images.unsplash.com/photo-1580234811497-9df7fd2f357e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1740&q=80'
                ];
                const randomImage = esportsImages[Math.floor(Math.random() * esportsImages.length)];
                heroSection.style.backgroundImage = `url('${randomImage}')`;
            }

            const currentYearSpan = document.getElementById('currentYear');
            if (currentYearSpan) {
                currentYearSpan.textContent = new Date().getFullYear();
            }

            // Contact Form Submission (Simulated - kept from previous)
            const contactForm = document.getElementById('contactFormReal');
            if (contactForm) {
                contactForm.addEventListener('submit', function(event) {
                    event.preventDefault();
                    alert('Thank you for your message! (This is a simulation)');
                    this.reset();
                });
            }
        });
  
    