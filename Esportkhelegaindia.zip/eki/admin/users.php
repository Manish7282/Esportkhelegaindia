<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// Restrict User Action
if (isset($_POST['restrict'])) {
    $user_id = $_POST['user_id'];
    $restriction_date = $_POST['restriction_date'];
    if ($restriction_date) {
        $stmt = $conn->prepare("UPDATE users SET restricted_until = ? WHERE id = ?");
        $stmt->bind_param("si", $restriction_date, $user_id);
        if ($stmt->execute()) {
            header("Location: users.php?message=User restricted successfully!");
            exit();
        } else {
            echo "<div class='alert alert-danger'>Error restricting user: " . $stmt->error . "</div>";
        }
    }
}

// Delete User Action
if (isset($_GET['delete_user'])) {
    $user_id = $_GET['delete_user'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        header("Location: users.php?message=User deleted successfully!");
        exit();
    } else {
        echo "<div class='alert alert-danger'>Error deleting user: " . $stmt->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Users - Admin Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
        }
        h2 {
            color: #0056A2;
        }
        .btn-secondary {
            background-color: #F37021;
            border: none;
        }
        .btn-secondary:hover {
            background-color: #e55f1c;
        }
        .btn-danger {
            background-color: #F37021;
            border: none;
        }
        .btn-danger:hover {
            background-color: #e55f1c;
        }
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
        .alert-warning {
            background-color: #fff3cd;
            border-color: #ffeeba;
            color: #856404;
        }
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        .table-bordered {
            border-color: #0056A2;
        }
        .table thead {
            background-color: #0056A2;
            color: white;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f2f2f2;
        }
        .table-striped tbody tr:hover {
            background-color: #e0e0e0;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">All Registered Users</h2>
    <a href="dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

    <?php
    if (isset($_GET['message'])) {
        echo "<div class='alert alert-success'>{$_GET['message']}</div>";
    }

    $sql = "SELECT id, name, email, wallet_balance, created_at, restricted_until FROM users ORDER BY id DESC";
    $result = $conn->query($sql);

    if (!$result) {
        echo "<div class='alert alert-danger'>Query Error: " . $conn->error . "</div>";
    } elseif ($result->num_rows > 0) {
        echo '<table class="table table-bordered table-striped">';
        echo '<thead><tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Wallet</th>
                <th>Created_At</th>
                <th>Actions</th>
              </tr></thead><tbody>';

        while ($row = $result->fetch_assoc()) {
            $restricted_until = $row['restricted_until'] ? $row['restricted_until'] : 'Not restricted';
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>₹{$row['wallet_balance']}</td>
                    <td>{$row['created_at']}</td>
                    <td>
                        <a href='?delete_user={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this user?\");'>Delete</a>
                    </td>
                  </tr>";
        }

        echo '</tbody></table>';
    } else {
        echo '<div class="alert alert-warning">No users found.</div>';
    }

    $conn->close();
    ?>
</div>
</body>
</html>
