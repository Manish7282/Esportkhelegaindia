<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../db.php';
$result = $conn->query("SELECT * FROM winners");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Manage Winners</title>
  <style>
    body {
      background: #121212;
      color: #e0e0e0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      padding: 40px 20px;
      margin: 0;
    }
    .container {
      max-width: 1000px;
      margin: auto;
      background: #1e1e1e;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 20px rgba(0, 86, 162, 0.5); /* Blue shadow */
    }
    h2 {
      color: #0056A2;
      margin-bottom: 25px;
      text-align: center;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 12px;
      border: 1px solid #333;
      text-align: center;
    }
    th {
      background: #0056A2;
      color: #fff;
    }
    td img {
      width: 60px;
      border-radius: 50%;
    }
    .btn {
      padding: 8px 16px;
      text-decoration: none;
      border-radius: 6px;
      font-weight: bold;
      display: inline-block;
    }
    .btn-add {
      background: #F37021;
      color: #fff;
      margin-bottom: 20px;
    }
    .btn-add:hover {
      background: #e55f1c;
    }
    .btn-edit {
      background: #0056A2;
      color: #fff;
    }
    .btn-edit:hover {
      background: #004080;
    }
    .btn-delete {
      background: #F37021;
      color: #fff;
    }
    .btn-delete:hover {
      background: #e55f1c;
    }
    .btn-secondary {
      background-color: #0056A2;
      color: #fff;
      padding: 8px 16px;
      border-radius: 6px;
      display: inline-block;
      text-decoration: none;
      margin-top: 20px;
    }
    .btn-secondary:hover {
      background-color: #004080;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Manage Winners</h2>
    <a class="btn btn-add" href="add-winner.php">+ Add Winner</a>
    <table>
      <thead>
        <tr>
          <th>Image</th>
          <th>Name</th>
          <th>Game</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><img src="<?= $row['image_url'] ?>"></td>
          <td><?= htmlspecialchars($row['name']) ?> "<?= htmlspecialchars($row['nickname']) ?>"</td>
          <td><?= htmlspecialchars($row['game']) ?></td>
          <td>
            <a class="btn btn-edit" href="edit-winner.php?id=<?= $row['id'] ?>">Edit</a>
            <a class="btn btn-delete" href="delete-winner.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this winner?')">Delete</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
  <a href="dashboard.php" class="btn-secondary">← Back to Dashboard</a>
</body>
</html>
