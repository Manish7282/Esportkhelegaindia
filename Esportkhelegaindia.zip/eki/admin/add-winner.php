<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $nickname = $_POST['nickname'];
    $game = $_POST['game'];
    $image_url = $_POST['image_url'];

    $stmt = $conn->prepare("INSERT INTO winners (name, nickname, game, image_url) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $nickname, $game, $image_url);
    $stmt->execute();
    header("Location: manage-winners.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Add/Edit Winner</title>
  <style>
    body {
      background: #121212;
      color: #e0e0e0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      padding: 40px 20px;
      margin: 0;
    }
    .container {
      max-width: 600px;
      margin: auto;
      background: #1e1e1e;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 20px rgba(0, 255, 150, 0.3);
    }
    h2 {
      color: #00ff99;
      text-align: center;
      margin-bottom: 25px;
    }
    label {
      display: block;
      margin-top: 15px;
    }
    input[type="text"] {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      background: #2c2c2c;
      color: #fff;
      border: 1px solid #555;
      border-radius: 6px;
    }
    button {
      margin-top: 20px;
      background: #00cc88;
      color: #111;
      border: none;
      padding: 12px 20px;
      font-weight: bold;
      border-radius: 6px;
      cursor: pointer;
      transition: 0.3s ease;
    }
    button:hover {
      background: #00ff99;
    }
    a.btn-back {
      display: inline-block;
      margin-top: 20px;
      color: #00ff99;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Add/Edit Winner</h2>
    <form method="post">
      <label>Name:</label>
      <input type="text" name="name" required value="<?= isset($row) ? htmlspecialchars($row['name']) : '' ?>">
      
      <label>Nickname:</label>
      <input type="text" name="nickname" required value="<?= isset($row) ? htmlspecialchars($row['nickname']) : '' ?>">
      
      <label>Game:</label>
      <input type="text" name="game" required value="<?= isset($row) ? htmlspecialchars($row['game']) : '' ?>">
      
      <label>Image URL:</label>
      <input type="text" name="image_url" required value="<?= isset($row) ? htmlspecialchars($row['image_url']) : '' ?>">
      
      <button type="submit"><?= isset($row) ? 'Update' : 'Add' ?> Winner</button>
      <br><a href="manage-winners.php" class="btn-back">← Back to Winners</a>
    </form>
  </div>
</body>
</html>
