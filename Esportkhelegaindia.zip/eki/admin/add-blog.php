<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../db.php'; // Ensure this path is correct and db.php initializes $conn

$feedback_message = null; // Variable to hold success or error messages
$message_type = ''; // 'success' or 'error'

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $image_url = $_POST['image_url']; // Consider validating this URL

    if (empty($title) || empty($content)) {
        $feedback_message = "Title and Content are required.";
        $message_type = 'error';
    } else {
        if ($conn) { // Check if $conn is initialized
            $stmt = $conn->prepare("INSERT INTO blogs (title, content, image_url) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("sss", $title, $content, $image_url);
                if ($stmt->execute()) {
                    $feedback_message = "Blog added successfully!";
                    $message_type = 'success';
                } else {
                    $feedback_message = "Error adding blog: " . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close();
            } else {
                $feedback_message = "Error preparing statement: " . $conn->error;
                $message_type = 'error';
            }
        } else {
            $feedback_message = "Database connection not established.";
            $message_type = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Add New Blog</title>
    <style>
        :root {
            --primary-orange: #F7931E;
            --primary-green: #138808; /* Green from Indian flag / image */
            --button-green-darker: #0f6b06;
            --text-dark: #333333;
            --text-light: #FFFFFF;
            --label-color: #003366; /* Dark blue for labels, inspired by image */
            --page-bg: #f4f6f8; /* Light grey page background */
            --form-bg: #FFFFFF; /* White form background */
            --input-border: #ced4da;
            --input-focus-border: #F7931E; /* Orange focus border */
            --input-focus-shadow: rgba(247, 147, 30, 0.25);
            --success-bg: #d4edda;
            --success-text: #155724;
            --success-border: #c3e6cb;
            --error-bg: #f8d7da;
            --error-text: #721c24;
            --error-border: #f5c6cb;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: var(--page-bg);
            color: var(--text-dark);
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .admin-container {
            width: 100%;
            max-width: 650px; /* Slightly wider for blog content */
        }

        .admin-header-actions {
            width: 100%;
            margin-bottom: 15px; /* Space below the link/header area */
            text-align: right; /* Aligns link to the right */
        }

        .back-to-dashboard-link {
            display: inline-block; /* Allows padding and respects text-align */
            color: var(--primary-orange);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9em;
            padding: 6px 12px; /* Adjusted padding */
            border-radius: 4px;
            border: 1px solid transparent; /* For potential border on hover/focus */
            transition: background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;
        }

        .back-to-dashboard-link:hover,
        .back-to-dashboard-link:focus { /* Added focus style for accessibility */
            background-color: var(--primary-orange);
            color: var(--text-light);
            text-decoration: none;
            border-color: var(--primary-orange);
            outline: none;
        }


        .feedback-message {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
            font-weight: 500;
            border: 1px solid transparent;
            box-sizing: border-box;
        }

        .feedback-message.success {
            background-color: var(--success-bg);
            color: var(--success-text);
            border-color: var(--success-border);
        }
        .feedback-message.error {
            background-color: var(--error-bg);
            color: var(--error-text);
            border-color: var(--error-border);
        }

        .blog-form-container {
            background-color: var(--form-bg);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .blog-form-container h2 {
            color: var(--primary-orange);
            text-align: center;
            margin-top: 0;
            margin-bottom: 30px;
            font-size: 2em;
        }

        .blog-form-container label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: var(--label-color); /* Dark blue labels */
            font-size: 0.95em;
        }

        .form-control { /* Styling for your existing .form-control class */
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 20px;
            background-color: #fff;
            color: var(--text-dark);
            border: 1px solid var(--input-border);
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
            transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
        }

        .form-control:focus {
            border-color: var(--input-focus-border);
            outline: none;
            box-shadow: 0 0 0 0.2rem var(--input-focus-shadow);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 120px; /* Decent default height for content */
        }

        .blog-form-container button[type="submit"] {
            background-color: var(--primary-green); /* Green button like image */
            color: var(--text-light);
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100%;
            margin-top: 10px;
        }

        .blog-form-container button[type="submit"]:hover {
            background-color: var(--button-green-darker);
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header-actions">
            <a href="dashboard.php" class="back-to-dashboard-link">← Back to Dashboard</a>
        </div>

        <?php if ($feedback_message): ?>
            <div class="feedback-message <?php echo htmlspecialchars($message_type); ?>">
                <?php echo htmlspecialchars($feedback_message); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="blog-form-container">
            <h2>Add New Blog</h2>

            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required class="form-control">

            <label for="content">Content:</label>
            <textarea id="content" name="content" required class="form-control" rows="6"></textarea>

            <label for="image_url">Image URL (Optional):</label>
            <input type="text" id="image_url" name="image_url" class="form-control" placeholder="e.g., https://example.com/image.jpg">
            
            <button type="submit">Add Blog</button>
        </form>
    </div>
</body>
</html>