<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../db.php';

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM blogs WHERE id = $id");
    header("Location: manage-blogs.php");
    exit();
}

$result = $conn->query("SELECT * FROM blogs ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Blogs</title>
    <style>
        body {
    background: #ffffff; /* white background */
    color: #000000; /* black text for contrast */
    font-family: Arial, sans-serif;
    padding: 40px;
}
table {
    width: 100%;
    background: #f9f9f9;
    border-collapse: collapse;
}
th, td {
    padding: 12px;
    border: 1px solid #ccc;
    text-align: left;
}
th {
    background: #F7931E; /* orange header */
    color: #ffffff; /* white text */
}
a.btn {
    padding: 6px 12px;
    background: #138808; /* green button */
    color: #ffffff;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
}
a.btn:hover {
    background: #0e6f06; /* darker green on hover */
}
.actions {
    display: flex;
    gap: 10px;
}

    </style>
</head>
<body>

<h2>Manage Blogs</h2>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Created At</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['title']) ?></td>
            <td><?= $row['created_at'] ?></td>
            <td class="actions">
                <a class="btn" href="edit-blog.php?id=<?= $row['id'] ?>">Edit</a>
                <a class="btn" href="manage-blogs.php?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this blog?')">Delete</a>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>

</body>
</html>
