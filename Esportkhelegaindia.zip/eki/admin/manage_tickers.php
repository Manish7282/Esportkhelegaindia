<?php
include '../db.php';
session_start();

// SECURITY CHECK
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// ADD NEW TICKER
if (isset($_POST['add'])) {
    $msg = $_POST['message'];
    $icon = $_POST['icon'];
    $link = $_POST['link'];
    $stmt = $conn->prepare("INSERT INTO tickers (message, icon, link) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $msg, $icon, $link);
    $stmt->execute();
}

// UPDATE TICKER
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $msg = $_POST['message'];
    $icon = $_POST['icon'];
    $link = $_POST['link'];
    $stmt = $conn->prepare("UPDATE tickers SET message=?, icon=?, link=? WHERE id=?");
    $stmt->bind_param("sssi", $msg, $icon, $link, $id);
    $stmt->execute();
}

// DELETE TICKER
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM tickers WHERE id=$id");
}

$tickers = $conn->query("SELECT * FROM tickers ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Tickers</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            background: #FFFFFF; /* white background */
            padding: 30px;
            color: #333333;
        }
        .form-container {
            background: #FFFFFF;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .icon-preview {
            font-size: 1.5rem;
            margin-left: 10px;
        }
        h3 {
            color: #FF7F00; /* orange header */
        }
        .table thead {
            background-color: #FF7F00; /* orange header */
            color: #FFFFFF;
        }
        .table tbody tr:hover {
            background-color: #FFF3E0; /* light orange on hover */
        }
        .btn-primary {
            background-color: #28A745; /* green button */
            border-color: #28A745;
        }
        .btn-primary:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
        .btn-warning {
            background-color: #FF7F00;
            border-color: #FF7F00;
            color: white;
        }
        .btn-warning:hover {
            background-color: #e06b00;
            border-color: #d16400;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
    </style>
</head>
<body>

<div class="container">
    <h3 class="text-center mb-4"><i class="fas fa-bullhorn"></i> Manage Tickers</h3>
    <a href="dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>

    <!-- Add/Edit Form -->
    <div class="form-container">
        <form method="post">
            <?php if (isset($_GET['edit'])):
                $editId = $_GET['edit'];
                $editData = $conn->query("SELECT * FROM tickers WHERE id=$editId")->fetch_assoc();
            ?>
                <input type="hidden" name="id" value="<?= $editData['id'] ?>">
            <?php endif; ?>

            <div class="mb-3">
                <label class="form-label">Ticker Message</label>
                <input type="text" name="message" class="form-control" required value="<?= isset($editData) ? $editData['message'] : '' ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Select Icon</label>
                <select name="icon" class="form-select" onchange="document.getElementById('icon-preview').className=this.value;">
                    <?php
                    $icons = ['fas fa-bullhorn', 'fas fa-trophy', 'fas fa-gamepad', 'fas fa-flag-checkered', 'fas fa-star', 'fas fa-bolt'];
                    foreach ($icons as $icon) {
                        $selected = (isset($editData) && $editData['icon'] === $icon) ? 'selected' : '';
                        echo "<option value=\"$icon\" $selected>$icon</option>";
                    }
                    ?>
                </select>
                <div class="mt-2">Preview: <i id="icon-preview" class="<?= isset($editData) ? $editData['icon'] : 'fas fa-bullhorn' ?>"></i></div>
            </div>

            <div class="mb-3">
                <label class="form-label">Link</label>
                <input type="text" name="link" class="form-control" value="<?= isset($editData) ? $editData['link'] : '#' ?>">
            </div>

            <button type="submit" name="<?= isset($editData) ? 'update' : 'add' ?>" class="btn btn-primary">
                <?= isset($editData) ? 'Update Ticker' : 'Add Ticker' ?>
            </button>
            <?php if (isset($editData)): ?>
                <a href="manage-ticker.php" class="btn btn-secondary ms-2">Cancel</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Table -->
    <table class="table table-bordered table-hover">
        <thead>
        <tr>
            <th>Message</th>
            <th>Icon</th>
            <th>Link</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($row = $tickers->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['message']) ?></td>
                <td><i class="<?= htmlspecialchars($row['icon']) ?>"></i> <?= htmlspecialchars($row['icon']) ?></td>
                <td><a href="<?= htmlspecialchars($row['link']) ?>" target="_blank"><?= htmlspecialchars($row['link']) ?></a></td>
                <td>
                    <a href="?edit=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>
