<?php
session_start();
include '../db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $amount = floatval($_POST['amount']);
    $transaction_type = $_POST['transaction_type']; // add or deduct
    $success = false;

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format.";
    } else {
        // Check if email exists in the database
        $checkStmt = $conn->prepare("SELECT wallet_balance FROM users WHERE email = ?");
        $checkStmt->bind_param("s", $email);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            $checkStmt->bind_result($current_balance);
            $checkStmt->fetch();

            if ($transaction_type == "deduct") {
                // Deduct money
                if ($amount > $current_balance) {
                    $message = "Error: User does not have enough balance to deduct ₹$amount.";
                } else {
                    $stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE email = ?");
                    $stmt->bind_param("ds", $amount, $email);
                    if ($stmt->execute()) {
                        // Log transaction
                        $stmt2 = $conn->prepare("INSERT INTO wallet_transactions (user_email, amount, type, reason) VALUES (?, ?, 'debit', ?)");
                        $reason = "Deducted by admin";
                        $stmt2->bind_param("sds", $email, $amount, $reason);
                        $stmt2->execute();

                        $message = "₹$amount deducted from $email's wallet!";
                        $success = true;
                    } else {
                        $message = "Error deducting from wallet.";
                    }
                }
            } else {
                // Add money
                $stmt = $conn->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE email = ?");
                $stmt->bind_param("ds", $amount, $email);
                if ($stmt->execute()) {
                    // Log transaction
                    $stmt2 = $conn->prepare("INSERT INTO wallet_transactions (user_email, amount, type, reason) VALUES (?, ?, 'credit', ?)");
                    $reason = "Added by admin";
                    $stmt2->bind_param("sds", $email, $amount, $reason);
                    $stmt2->execute();

                    $message = "₹$amount added to $email's wallet!";
                    $success = true;
                } else {
                    $message = "Error adding to wallet.";
                }
            }
        } else {
            $message = "Error: User with email '$email' is not registered.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add/Deduct Money to User Wallet</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            background: #fff;
            border-radius: 15px;
            padding: 30px 20px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            animation: fadeIn 0.8s ease-in-out;
        }
        h2 {
            color: #ff8c00;
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input, select {
            padding: 12px;
            margin: 10px 0;
            border: 2px solid #ccc;
            border-radius: 8px;
            transition: border-color 0.3s;
            font-size: 16px;
        }
        input:focus, select:focus {
            border-color: #ff8c00;
            outline: none;
        }
        button {
            background-color: #ff8c00;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
            transition: background-color 0.3s, transform 0.2s;
        }
        button:hover {
            background-color: #e67600;
            transform: scale(1.05);
        }
        .message {
            margin-top: 15px;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            animation: slideDown 0.5s ease-out;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        a {
            display: block;
            margin-top: 15px;
            text-align: center;
            color: #ff8c00;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @media (max-width: 480px) {
            .container {
                padding: 20px 15px;
                max-width: 90%;
            }
            input, select, button {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add/Deduct Money to User Wallet</h2>
        <form method="post">
            <input type="email" name="email" placeholder="User Email" required>
            <input type="number" name="amount" placeholder="Amount" step="0.01" required>
            <select name="transaction_type" required>
                <option value="add">Add Money</option>
                <option value="deduct">Deduct Money</option>
            </select>
            <button type="submit">Submit</button>
        </form>
        <?php if (isset($message)): ?>
            <div class="message <?= $success ? 'success' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
