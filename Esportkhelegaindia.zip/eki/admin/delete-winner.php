<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../db.php';

$id = $_GET['id'];
$stmt = $conn->prepare("DELETE FROM winners WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: manage-winners.php");
exit();
?>
