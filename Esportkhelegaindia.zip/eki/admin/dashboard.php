<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../db.php';

// Total Users
$user_count = 0;
$result = $conn->query("SELECT COUNT(*) AS total FROM users");
if ($result) {
    $user_count = $result->fetch_assoc()['total'];
}

// Total Contests
$contest_count = 0;
// Corrected query: COUNT(DISTINCT contest_id) might not be what you want if 'contests' table has unique contest_id as primary key.
// Assuming 'contests' table has one row per contest and 'id' or 'contest_id' is the primary key.
// If 'contests' table stores contest details and 'contest_id' is unique, then:
$result = $conn->query("SELECT COUNT(*) AS total FROM contests");
// If 'contests' table can have multiple rows for the same contest_id (e.g., different rounds), then original was okay.
// For clarity, I'll assume 'contests' table has unique contests.
if ($result) {
    $contest_count = $result->fetch_assoc()['total'];
}

// Total Entries
$entry_count = 0;
$result = $conn->query("SELECT COUNT(*) AS total FROM contest_entries");
if ($result) {
    $entry_count = $result->fetch_assoc()['total'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Admin Dashboard - Tiranga Theme</title>
<style>
  :root {
    --saffron: #FF9933;
    --white: #FFFFFF;
    --green: #138808;
    --navy-blue: #0033A0; /* A slightly more vibrant navy */
    --dark-bg: #1A202C; /* Dark bluish-gray */
    --light-text: #E2E8F0; /* Light gray for text */
  }

  body {
    background: var(--dark-bg);
    color: var(--light-text);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    display: flex;
    flex-direction: column; /* Allow for potential header/footer later */
    justify-content: center; /* Center content vertically for short pages */
    align-items: center; /* Center content horizontally */
    min-height: 100vh;
    padding: 20px;
    margin: 0;
    box-sizing: border-box;
  }

  .container {
    background: linear-gradient(135deg, var(--green), #106c07); /* Subtle gradient for depth */
    color: var(--white);
    padding: 30px 25px;
    border-radius: 15px;
    box-shadow: 0 5px 25px rgba(0, 0, 0, 0.4), 0 0 0 3px var(--saffron); /* Saffron border effect */
    max-width: 600px;
    width: 100%;
    text-align: center;
    animation: fadeInScale 0.7s ease-out forwards;
    border: 2px solid var(--saffron); /* Actual saffron border */
  }

  h2 {
    color: var(--saffron);
    margin-top: 0;
    margin-bottom: 30px;
    font-weight: 700;
    font-size: 2rem; /* Responsive base */
    text-transform: uppercase;
    letter-spacing: 1.5px;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
  }

  p {
    font-size: 1.1rem; /* Responsive base */
    margin: 12px 0;
    line-height: 1.6;
  }
  p strong {
    color: var(--saffron); /* Highlight numbers */
    font-weight: 700;
  }

  .links {
    margin-top: 35px;
    display: flex;
    flex-wrap: wrap; /* Allow links to wrap on smaller screens */
    justify-content: center;
    gap: 15px; /* Spacing between links */
  }

  .links a {
    background: var(--white);
    color: var(--green);
    padding: 10px 18px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 0.9rem; /* Responsive base */
    text-decoration: none;
    border: 2px solid var(--navy-blue);
    transition: all 0.3s ease;
    flex-grow: 0; /* Don't grow by default */
    flex-shrink: 0; /* Don't shrink by default */
  }

  .links a:hover,
  .links a:focus {
    background: var(--saffron);
    color: var(--dark-bg);
    border-color: var(--saffron);
    box-shadow: 0 0 15px rgba(255, 153, 51, 0.7);
    transform: translateY(-3px);
  }

  @keyframes fadeInScale {
    0% {
      opacity: 0;
      transform: scale(0.9);
    }
    100% {
      opacity: 1;
      transform: scale(1);
    }
  }

  /* Responsive Adjustments */
  @media (max-width: 768px) {
    .container {
      padding: 25px 20px;
    }
    h2 {
      font-size: 1.8rem;
    }
    p {
      font-size: 1rem;
    }
    .links a {
      padding: 9px 15px;
      font-size: 0.85rem;
    }
  }

  @media (max-width: 480px) {
    body {
      padding: 15px;
    }
    .container {
      padding: 20px 15px;
      border-radius: 10px;
    }
    h2 {
      font-size: 1.6rem;
      margin-bottom: 20px;
    }
    p {
      font-size: 0.95rem;
      margin: 10px 0;
    }
    .links {
      flex-direction: column; /* Stack links vertically */
      gap: 12px;
    }
    .links a {
      width: 100%; /* Make links take full width */
      padding: 12px 15px; /* Adjust padding for full width */
      font-size: 0.9rem;
      box-sizing: border-box; /* Ensure padding doesn't break layout */
    }
  }
  .links a.logout-btn {
    background: #dc3545; /* Bootstrap red */
    color: #fff;
    border-color: #dc3545;
}

.links a.logout-btn:hover,
.links a.logout-btn:focus {
    background: #c82333;
    color: #fff;
    box-shadow: 0 0 15px rgba(220, 53, 69, 0.6);
}

</style>
</head>
<body>

<div class="container">
  <h2>Welcome, Admin!</h2>
  <p>Total Users: <strong><?= htmlspecialchars($user_count) ?></strong></p>
  <p>Total Contests: <strong><?= htmlspecialchars(2) ?></strong></p>

  <div class="links">

    <a href="users.php">Manage Users</a>
    <a href="manage_tickers.php">Manage Tickers</a>
    <a href="add_money.php">Add Money</a> <!-- Changed "Add" to "Add Money" for clarity -->
    <a href="manage-winners.php">Manage Winners</a>
    <a href="add-blog.php">Add Blog</a>
    <a href="manage-blogs.php">Manage Blogs</a>
     <a href="manage_registrations.php">Manage Contests</a>
    <a href="logout.php" class="logout-btn">Logout</a>

  </div>
</div>

</body>
</html>