<?php
session_start();
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']);  // Make sure DB password is also md5 hashed

    if ($stmt = $conn->prepare("SELECT * FROM admin_users WHERE username = ? AND password = ?")) {
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $_SESSION['admin'] = $username;
            header("Location: dashboard.php");
            exit();
        } else {
            // This error message will appear above the DOCTYPE, unstyled by the main CSS.
            // Adding some basic inline styles to make it somewhat visible.
            echo "<p style='color: #FF6B6B; text-align:center; background-color: rgba(255, 107, 107, 0.1); padding: 10px; border: 1px solid rgba(255, 107, 107, 0.3); border-radius:5px; max-width: 380px; margin: 20px auto;'>Invalid login credentials!</p>";
        }
    } else {
        // This error message will also appear above the DOCTYPE.
        echo "<p style='color: #FF6B6B; text-align:center; background-color: rgba(255, 107, 107, 0.1); padding: 10px; border: 1px solid rgba(255, 107, 107, 0.3); border-radius:5px; max-width: 380px; margin: 20px auto;'>Query failed: " . htmlspecialchars($conn->error) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Login - Tiranga Theme</title>
  <style>
    :root {
      --saffron: #FF9933;
      --white: #FFFFFF;
      --green: #138808;
      --navy-blue: #0033A0; /* For borders or subtle accents */

      --dark-bg: #121212;
      --container-bg: #1E1E1E;
      --input-bg: #2C2C2C;
      --input-border: #4A4A4A;
      --input-border-focus: var(--green);

      --light-text: #E0E0E0;
      --dim-text: #888888;
      --label-active-color: var(--saffron);

      /* RGB versions for rgba() shadows */
      --saffron-rgb: 255, 153, 51;
      --green-rgb: 19, 136, 8;
    }

    html {
        box-sizing: border-box;
    }
    *, *::before, *::after {
        box-sizing: inherit;
    }

    body {
      background: var(--dark-bg);
      color: var(--light-text);
      display: flex;
      flex-direction: column; /* To allow PHP errors to show above the form if they are echoed before DOCTYPE */
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0; /* Removed default padding and previous padding: 15px for better control with wrapper */
    }

    .wrapper {
      background: var(--container-bg);
      padding: 40px 30px;
      border-radius: 12px;
      box-shadow: 0 5px 20px rgba(var(--saffron-rgb), 0.2); /* Saffron shadow */
      width: 100%;
      max-width: 400px;
      opacity: 0;
      animation: fadeIn 0.8s forwards;
      border-top: 4px solid var(--saffron); /* Saffron top accent */
      margin: 15px; /* Ensures some space from viewport edges on very small screens */
    }

    form h2 {
      text-align: center;
      margin-top: 0; /* Good practice if it's the first element */
      margin-bottom: 30px;
      color: var(--saffron); /* Saffron heading */
      font-weight: 700;
      opacity: 0;
      animation: slideDown 0.8s forwards;
      animation-delay: 0.3s;
      text-transform: uppercase;
      letter-spacing: 1.5px;
    }

    .input-group {
      position: relative;
      margin-bottom: 25px;
      opacity: 0;
      animation: slideUp 0.8s forwards;
    }
    /* Target .input-group specifically within a form to avoid affecting other .input-group if any */
    form .input-group:nth-of-type(1) { animation-delay: 0.45s; }
    form .input-group:nth-of-type(2) { animation-delay: 0.6s; }

    .input-group input {
      width: 100%;
      padding: 12px 10px;
      background: var(--input-bg);
      border: 1px solid var(--input-border);
      border-radius: 6px;
      color: var(--light-text); /* Consistent text color */
      font-size: 16px;
      transition: border-color 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease;
    }
    .input-group input:focus {
      border-color: var(--input-border-focus); /* Green border on focus */
      outline: none;
      box-shadow: 0 0 8px rgba(var(--green-rgb), 0.3);
      background: #252525; /* Slightly different background on focus */
    }

    .input-group label {
      position: absolute;
      left: 12px;
      top: 12px;
      color: var(--dim-text);
      pointer-events: none;
      transition: 0.2s ease all;
      font-size: 14px;
      text-transform: capitalize;
    }
    .input-group input:focus + label,
    .input-group input:not(:placeholder-shown) + label {
      top: -10px;
      font-size: 12px;
      color: var(--label-active-color); /* Saffron active label */
      background: var(--container-bg); /* Match wrapper background for floating effect */
      padding: 0 6px;
    }

    .remember {
      margin-bottom: 20px;
      font-size: 14px;
      color: var(--light-text); /* Consistent light text */
      opacity: 0;
      animation: slideUp 0.8s forwards;
      animation-delay: 0.75s;
      user-select: none;
    }
    .remember input[type="checkbox"] {
      margin-right: 8px;
      transform: scale(1.2);
      cursor: pointer;
      vertical-align: middle;
      accent-color: var(--green); /* Green checkbox */
    }

    button[type="submit"] {
      width: 100%;
      background: var(--green); /* Green button */
      border: none;
      padding: 14px;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 700;
      color: var(--white); /* White text on green button */
      cursor: pointer;
      transition: background 0.3s ease, box-shadow 0.3s ease, transform 0.2s ease;
      opacity: 0;
      animation: slideUp 0.8s forwards;
      animation-delay: 0.9s;
    }
    button[type="submit"]:hover {
      background: var(--saffron); /* Saffron on hover */
      color: var(--dark-bg); /* Dark text on Saffron for contrast */
      box-shadow: 0 0 12px rgba(var(--saffron-rgb), 0.5);
      transform: translateY(-2px); /* Subtle lift */
    }

    .signUp-link { /* This section might be less relevant for an Admin Login */
      margin-top: 18px;
      text-align: center;
      font-size: 14px;
      color: var(--dim-text);
      opacity: 0;
      animation: fadeIn 0.8s forwards;
      animation-delay: 1.1s;
    }
    .signUp-link a {
      color: var(--saffron); /* Saffron link */
      text-decoration: none;
      font-weight: 600;
    }
    .signUp-link a:hover {
      text-decoration: underline;
      color: var(--green); /* Green on hover for variety */
    }

    @media (max-width: 480px) {
      .wrapper {
        padding: 30px 20px;
        margin: 10px; /* Ensure some space from edges */
      }
       form h2 {
          font-size: 1.5rem; /* Adjust heading for smaller screens */
      }
      .input-group input, button[type="submit"] {
          font-size: 15px; /* Adjust font size for form elements */
      }
    }

    /* Animations */
    @keyframes fadeIn {
      to {
        opacity: 1;
      }
    }
    @keyframes slideDown {
      from {
        opacity: 0;
        transform: translateY(-20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  </style>
</head>
<body>
  <?php
    // PHP errors are echoed here, before the main content.
    // The inline styles added to the PHP echo statements are a workaround because these messages
    // are output before the main stylesheet is processed.
  ?>
  <div class="wrapper">
    <div class="form-wrapper sign-in"> <!-- 'sign-in' class from original, kept for compatibility if used by other JS -->
      <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <h2>Admin Login</h2>
        <!-- If errors were to be displayed *inside* the form via PHP variable:
        <?php // if (!empty($login_error_message_variable)) echo "<p class='error-message'>{$login_error_message_variable}</p>"; ?>
        -->
        <div class="input-group">
          <input type="text" name="username" id="username" placeholder=" " required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" />
          <label for="username">Username</label>
        </div>
        <div class="input-group">
          <input type="password" name="password" id="password" placeholder=" " required />
          <label for="password">Password</label>
        </div>
        <div class="remember">
          <label><input type="checkbox" id="rememberMe" name="rememberMe"/> Remember me</label>
        </div>
        <button type="submit">Login</button>
        <div class="signUp-link" style="display: none;"> <!-- Hiding this by default for an admin panel -->
          <p>Don't have an account? <a href="Register.php" class="signUpBtn-link">Register</a></p>
        </div>
      </form>
    </div>
  </div>

  <script>
    const rememberCheckbox = document.getElementById('rememberMe');
    if (rememberCheckbox) { // Good practice to check if element exists
        rememberCheckbox.addEventListener('change', () => {
          if (rememberCheckbox.checked) {
            console.log("Remember me enabled");
          } else {
            console.log("Remember me disabled");
          }
        });
    }
  </script>
</body>
</html>