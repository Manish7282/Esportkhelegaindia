<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include '../db.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM blogs WHERE id = $id");
$blog = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $image_url = $_POST['image_url'];

    $stmt = $conn->prepare("UPDATE blogs SET title=?, content=?, image_url=? WHERE id=?");
    $stmt->bind_param("sssi", $title, $content, $image_url, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: manage-blogs.php");
    exit();
}
?>

<form method="POST" style="max-width: 600px; margin: 20px auto; background: #222; padding: 20px; color: white;">
    <h2>Edit Blog</h2>
    <label>Title:</label><br>
    <input type="text" name="title" value="<?= htmlspecialchars($blog['title']) ?>" class="form-control" required><br>
    <label>Content:</label><br>
    <textarea name="content" rows="6" class="form-control" required><?= htmlspecialchars($blog['content']) ?></textarea><br>
    <label>Image URL:</label><br>
    <input type="text" name="image_url" value="<?= htmlspecialchars($blog['image_url']) ?>" class="form-control"><br>
    <button type="submit">Update Blog</button>
</form>
