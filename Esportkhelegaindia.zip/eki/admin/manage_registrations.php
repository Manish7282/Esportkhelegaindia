<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$host = 'localhost'; // Change if needed
$username = 'root'; // Change if needed
$password = ''; // Change if needed
$dbname = 'eki_db'; // Change to your database name

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle deletion if id is passed
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $conn->query("DELETE FROM contest_registrations WHERE id = $delete_id"); // Adjust if needed
    header("Location: manage_registrations.php?deleted=1");
    exit();
}

// Fetch contest registrations
$sql = "SELECT * FROM contest_registrations ORDER BY registration_timestamp DESC"; // Adjust if needed
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Contest Registrations</title>
    <style>
        body {
            background-color: #FFFFFF; /* white background */
            color: #333333; /* dark text */
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        h1 {
            color: #FF7F00; /* orange header */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #FFFFFF; /* white background for table */
            color: #333333;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 10px;
            border: 1px solid #CCCCCC; /* light border */
            text-align: left;
        }
        th {
            background-color: #FF7F00; /* orange header */
            color: #FFFFFF; /* white text */
        }
        a {
            color: #FF7F00; /* orange links */
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .btn-delete {
            color: red;
            font-weight: bold;
        }
        .msg {
            margin-top: 20px;
            color: #28A745; /* green success message */
        }
        .btn-back {
            display: inline-block;
            padding: 10px 15px;
            background-color: #28A745; /* green button */
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .btn-back:hover {
            background-color: #218838; /* darker green on hover */
        }
    </style>
</head>
<body>
    <h1>Manage Contest Registrations</h1>

    <?php if (isset($_GET['deleted'])): ?>
        <p class="msg">Registration deleted successfully!</p>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Contest Name</th>
            <th>Game Type</th>
            <th>Player Game ID</th>
            <th>In-game Name</th>
            <th>Email</th>
            <th>Registered At</th>
            <th>Actions</th>
        </tr>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['user_id']) ?></td>
                    <td><?= htmlspecialchars($row['contest_name']) ?></td>
                    <td><?= htmlspecialchars($row['game_type']) ?></td>
                    <td><?= htmlspecialchars($row['player_game_id']) ?></td>
                    <td><?= htmlspecialchars($row['player_in_game_name']) ?></td>
                    <td><?= htmlspecialchars($row['player_email']) ?></td>
                    <td><?= htmlspecialchars($row['registration_timestamp']) ?></td>
                    <td>
                        <a href="manage_registrations.php?delete_id=<?= $row['id'] ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this registration?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="9">No registrations found.</td></tr>
        <?php endif; ?>
    </table>

    <p><a href="dashboard.php" class="btn-back">Back to Dashboard</a></p>
</body>
</html>
