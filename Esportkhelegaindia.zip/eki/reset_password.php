<?php
include 'db.php'; // Ensure this path is correct

$email_from_get = $_GET['email'] ?? '';
$message_to_display = ""; // For user feedback

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email_from_post = trim($_POST['email']);
    $otp_entered = trim($_POST['otp']);
    $new_password_plain = $_POST['new_password']; // Get plain text password

    if (empty($email_from_post) || empty($otp_entered) || empty($new_password_plain)) {
        $message_to_display = "<div class='alert alert-danger'>All fields are required.</div>";
    } elseif (strlen($new_password_plain) < 6) { // Basic password length check
        $message_to_display = "<div class='alert alert-danger'>Password must be at least 6 characters long.</div>";
    } else {
        $new_pass_hashed = password_hash($new_password_plain, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("SELECT otp_code, otp_expiry FROM users WHERE email = ?");
        if (!$stmt) {
            error_log("Prepare failed (select otp): (" . $conn->errno . ") " . $conn->error);
            $message_to_display = "<div class='alert alert-danger'>An error occurred. Please try again later.</div>";
        } else {
            $stmt->bind_param("s", $email_from_post);
            $stmt->execute();
            $result_otp_check = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($result_otp_check && $result_otp_check['otp_code'] == $otp_entered && $result_otp_check['otp_expiry'] > date("Y-m-d H:i:s")) {
                $update_stmt = $conn->prepare("UPDATE users SET password = ?, otp_code = NULL, otp_expiry = NULL WHERE email = ?");
                if (!$update_stmt) {
                    error_log("Prepare failed (update pass): (" . $conn->errno . ") " . $conn->error);
                    $message_to_display = "<div class='alert alert-danger'>An error occurred while updating password.</div>";
                } else {
                    $update_stmt->bind_param("ss", $new_pass_hashed, $email_from_post);
                    if ($update_stmt->execute()) {
                        $message_to_display = "<div class='alert alert-success'>Password has been reset successfully! Redirecting to login...</div>";
                        echo "<script>
                            setTimeout(function() {
                                window.location.href = 'login.php';
                            }, 3000); // Redirect after 3 seconds
                        </script>";
                    } else {
                        error_log("Execute failed (update pass): (" . $update_stmt->errno . ") " . $update_stmt->error);
                        $message_to_display = "<div class='alert alert-danger'>Failed to update password. Please try again.</div>";
                    }
                    $update_stmt->close();
                }
            } else if ($result_otp_check && $result_otp_check['otp_code'] == $otp_entered && $result_otp_check['otp_expiry'] <= date("Y-m-d H:i:s")) {
                $message_to_display = "<div class='alert alert-danger'>Your OTP has expired. Please request a new one.</div>";
            } else {
                $message_to_display = "<div class='alert alert-danger'>Invalid OTP. Please check the code and try again.</div>";
            }
        }
    }
    if (isset($conn)) {
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Reset Password - Tiranga Theme</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Font Awesome for eye icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <!-- Bootstrap CSS (optional, if you need its grid or other components elsewhere, otherwise can be removed) -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" /> -->
    <style>
        :root {
          --saffron: #FF9933;
          --white: #FFFFFF;
          --green: #138808;
          --navy-blue: #0033A0;

          --dark-bg: #121212;
          --container-bg: #1E1E1E;
          --input-bg: #2C2C2C;
          --input-border: #4A4A4A;
          --input-border-focus: var(--green);

          --light-text: #E0E0E0;
          --dim-text: #888888;

          /* RGB for shadows */
          --saffron-rgb: 255, 153, 51;
          --green-rgb: 19, 136, 8;
        }

        html {
            box-sizing: border-box;
        }
        *, *::before, *::after {
            box-sizing: inherit;
        }

        body {
            background-color: var(--dark-bg);
            color: var(--light-text);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .reset-password-wrapper {
            width: 100%;
            max-width: 420px;
            padding: 0 15px; /* Provides space from screen edges on small devices */
        }

        .reset-password-box {
            background: var(--container-bg);
            padding: 35px 30px;
            border-radius: 12px;
            box-shadow: 0 5px 25px rgba(var(--saffron-rgb), 0.15);
            border-top: 4px solid var(--saffron);
            animation: fadeInForm 0.7s ease-out;
            width: 100%; /* Fills the padded wrapper */
        }

        @keyframes fadeInForm {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .reset-password-box h3 {
            text-align: center;
            color: var(--saffron);
            margin-top: 0;
            margin-bottom: 30px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .form-group {
            margin-bottom: 20px;
        }
        .form-group:last-of-type { /* For the password input before the button */
            margin-bottom: 25px;
        }

        .form-control-custom {
            width: 100%;
            padding: 12px 15px;
            background-color: var(--input-bg);
            border: 1px solid var(--input-border);
            color: var(--light-text);
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-control-custom::placeholder {
            color: var(--dim-text);
        }
        .form-control-custom:focus {
            border-color: var(--input-border-focus);
            box-shadow: 0 0 8px rgba(var(--green-rgb), 0.3);
            outline: none;
        }

        .password-wrapper { /* Container for password input and toggle icon */
            position: relative;
        }
        .password-wrapper .form-control-custom {
            padding-right: 45px; /* Space for the icon */
        }
        .password-wrapper .toggle-password {
            position: absolute;
            right: 20px; /* Position icon from the right */
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--dim-text);
            font-size: 18px;
            user-select: none;
            transition: color 0.3s ease;
        }
        .password-wrapper .toggle-password:hover {
            color: var(--saffron);
        }

        .btn-custom-primary { /* Replaces .btn-success for thematic consistency */
            background-color: var(--green);
            color: var(--white);
            border: none;
            font-weight: bold;
            padding: 12px 15px;
            width: 100%;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease, transform 0.2s ease;
        }
        .btn-custom-primary:hover {
            background-color: var(--saffron);
            color: var(--dark-bg);
            box-shadow: 0 0 12px rgba(var(--saffron-rgb), 0.4);
            transform: translateY(-2px);
        }

        .alert {
            padding: 12px 15px;
            margin-top: 0; /* Will be handled by being first child after h3 if needed */
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 6px;
            font-size: 0.95em;
            text-align: center;
        }
        .reset-password-box > .alert:first-child { /* If alert is directly after h3 (or any other element) */
             margin-top: -10px; /* Pull up slightly if it's just after the heading */
        }
        .alert-success {
            color: #0f5132;
            background-color: #d1e7dd;
            border-color: #badbcc;
        }
        .alert-danger {
            color: #842029;
            background-color: #f8d7da;
            border-color: #f5c2c7;
        }

        @media (max-width: 480px) {
            .reset-password-box {
                padding: 30px 20px;
            }
            .reset-password-box h3 {
                font-size: 1.6rem;
                margin-bottom: 25px;
            }
            .form-control-custom, .btn-custom-primary {
                font-size: 15px;
                padding: 11px 14px;
            }
            .alert {
                font-size: 0.9em;
                padding: 10px;
            }
        }
    </style>
</head>
<body>

<div class="reset-password-wrapper">
    <div class="reset-password-box">
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="hidden" name="email" value="<?= htmlspecialchars($_POST['email'] ?? $email_from_get) ?>">
            <h3>Reset Password</h3>

            <?php if (!empty($message_to_display)) echo $message_to_display; ?>

            <div class="form-group">
                <input type="text" name="otp" placeholder="Enter OTP" required class="form-control-custom" />
            </div>

            <div class="form-group password-wrapper">
                <input type="password" name="new_password" placeholder="New Password (min. 6 characters)" required class="form-control-custom" id="new_password" />
                <i class="fas fa-eye toggle-password" id="togglePassword"></i>
            </div>

            <button type="submit" class="btn-custom-primary">Reset Password</button>
            <!-- Note: Original HTML used .btn-success. Changed to .btn-custom-primary for theme. -->
        </form>
    </div>
</div>

<script>
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('new_password');

    if (togglePassword && passwordInput) { // Good practice to check if elements exist
        togglePassword.addEventListener('click', () => {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            togglePassword.classList.toggle('fa-eye');
            togglePassword.classList.toggle('fa-eye-slash');
        });
    }
</script>

</body>
</html>