<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';
$user_email = $_SESSION['user_email'] ?? '';

// Determine current page for active link styling
$current_page_basename = basename($_SERVER['PHP_SELF']); // e.g., profile.php, home.php
// Try to get hash from URL. Note: PHP might not see it if set by JS after load.
// This is best for initial load from a direct link with a hash.
$url_components = parse_url($_SERVER['REQUEST_URI']);
$current_page_hash = isset($url_components['fragment']) ? $url_components['fragment'] : '';


// --- Database Connection ---
$conn = new mysqli('localhost', 'root', '', 'eki_db');
if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}
// --- End Database Connection ---

$registration_message = '';
$registration_message_type = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['join_contest_submit'])) {
    $game_type = $_POST['game_type'] ?? '';
    $player_game_id = trim($_POST['player_game_id'] ?? '');
    $player_in_game_name = trim($_POST['player_in_game_name'] ?? '');
    $player_email_form = trim($_POST['player_email'] ?? ''); // Use a different var name to avoid conflict
    $contest_name = $game_type . " Contest";

    if (empty($game_type) || empty($player_game_id) || empty($player_in_game_name) || empty($player_email_form)) {
        $_SESSION['registration_message'] = "All fields are required.";
        $_SESSION['registration_message_type'] = 'error';
    } elseif (!filter_var($player_email_form, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['registration_message'] = "Invalid email format.";
        $_SESSION['registration_message_type'] = 'error';
    } else {
        $stmt_check = $conn->prepare("SELECT id FROM contest_registrations WHERE user_id = ? AND game_type = ?");
        if ($stmt_check) {
            $stmt_check->bind_param("is", $user_id, $game_type);
            $stmt_check->execute();
            $stmt_check->store_result();

            if ($stmt_check->num_rows > 0) {
                $_SESSION['registration_message'] = "You have already registered for the " . htmlspecialchars($game_type) . " contest.";
                $_SESSION['registration_message_type'] = 'info';
            } else {
                $stmt = $conn->prepare("INSERT INTO contest_registrations (user_id, contest_name, game_type, player_game_id, player_in_game_name, player_email) VALUES (?, ?, ?, ?, ?, ?)");
                if ($stmt) {
                    $stmt->bind_param("isssss", $user_id, $contest_name, $game_type, $player_game_id, $player_in_game_name, $player_email_form);
                    if ($stmt->execute()) {
                        $_SESSION['registration_message'] = "Successfully registered for the " . htmlspecialchars($game_type) . " contest!";
                        $_SESSION['registration_message_type'] = 'success';
                    } else {
                        $_SESSION['registration_message'] = "Error during registration: " . $stmt->error;
                        $_SESSION['registration_message_type'] = 'error';
                    }
                    $stmt->close();
                } else {
                    $_SESSION['registration_message'] = "Error preparing statement for insert: " . $conn->error;
                    $_SESSION['registration_message_type'] = 'error';
                }
            }
            $stmt_check->close();
        } else {
            $_SESSION['registration_message'] = "Error preparing statement for check: " . $conn->error;
            $_SESSION['registration_message_type'] = 'error';
        }
    }
    header("Location: profile.php#contests");
    exit();
}

if (isset($_SESSION['registration_message'])) {
    $registration_message = $_SESSION['registration_message'];
    $registration_message_type = $_SESSION['registration_message_type'];
    unset($_SESSION['registration_message']);
    unset($_SESSION['registration_message_type']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/style.css"> <!-- Assuming you have this or remove if not -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - <?php echo htmlspecialchars($user_name); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --navbar-orange: #F7931E;
            --link-green: #138808;
            --text-white: #FFFFFF;
            --text-dark: #333333;
            --page-bg-white: #FFFFFF;
            --dropdown-bg: #FFFFFF;
            --dropdown-hover-bg: #f0f0f0;
            --navbar-height: 60px;
            --success-bg: #d4edda;
            --success-text: #155724;
            --error-bg: #f8d7da;
            --error-text: #721c24;
            --info-bg: #cce5ff;
            --info-text: #004085;
        }

        html {
            scroll-behavior: smooth;
            scroll-padding-top: var(--navbar-height); /* Offset for fixed navbar */
        }

        body {
            background: var(--page-bg-white);
            color: var(--text-dark);
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding-top: var(--navbar-height);
        }

        /* Navbar */
        .navbar {
            background: var(--navbar-orange);
            padding: 0 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--text-white);
            height: var(--navbar-height);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            box-sizing: border-box;
            z-index: 1000;
            box-shadow: 0 2px 5px rgba(0,0,0,0.15);
        }

        .navbar-left, .navbar-right { display: flex; align-items: center; }
        .navbar-center { display: flex; justify-content: center; flex-grow: 1; }
        .logo { height: 40px; margin-right: 10px; transition: transform 0.3s ease; }
        .logo:hover { transform: scale(1.05); }
        .site-name { font-size: 1.5em; font-weight: bold; color: var(--text-white); letter-spacing: 0.5px; }
        
        .nav-links a {
            color: var(--text-white); /* Default color */
            text-decoration: none;
            margin: 0 15px;
            font-weight: bold;
            font-size: 1em;
            padding: 5px 0;
            transition: color 0.3s, opacity 0.3s;
        }
        .nav-links a.active-link { /* Active link is green */
            color: var(--link-green);
        }
        .nav-links a:hover:not(.active-link) { /* Hover for non-active links */
            opacity: 0.8;
        }
         .nav-links a.active-link:hover { /* Hover for active links */
             opacity: 0.8; /* or 1 if you want no change */
         }


        .user-profile { position: relative; display: flex; align-items: center; cursor: pointer; color: var(--text-white); }
        .user-icon { font-size: 1.8em; margin-right: 8px; color: var(--text-white); }
        .user-profile span { font-weight: bold; }
        .user-profile .fa-caret-down { color: var(--text-white); }

        .dropdown {
            display: none; opacity: 0; visibility: hidden; transform: translateY(-10px);
            position: absolute; right: 0; top: calc(100% + 10px);
            background-color: var(--dropdown-bg); border: 1px solid #ccc;
            min-width: 180px; box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 10; border-radius: 4px;
            transition: opacity 0.2s ease, transform 0.2s ease, visibility 0.2s ease;
        }
        .dropdown.active { display: block; opacity: 1; visibility: visible; transform: translateY(0); }
        .dropdown a { color: var(--text-dark); padding: 12px 16px; text-decoration: none; display: flex; align-items: center; font-weight: normal; transition: background-color 0.2s ease; }
        .dropdown a i { margin-right: 10px; width: 20px; text-align: center; color: var(--text-dark); }
        .dropdown a:hover { background-color: var(--dropdown-hover-bg); }
        .hamburger { display: none; font-size: 1.8em; cursor: pointer; color: var(--text-white); }

        .content {
            padding: 30px; max-width: 960px; margin: 0 auto;
            animation: contentFadeIn 0.8s ease-out forwards;
        }
        @keyframes contentFadeIn { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }

        .content > h1, .content > p:first-of-type {
            opacity: 0; animation: elementSlideIn 0.7s ease-out forwards;
        }
        .content > h1 { animation-delay: 0.2s; }
        .content > p:first-of-type { animation-delay: 0.3s; line-height: 1.6; }
        @keyframes elementSlideIn { from { opacity: 0; transform: translateX(-30px); } to { opacity: 1; transform: translateX(0); } }

        .content section { margin-bottom: 40px; }
        .content section h2, .content section h3, .content section p, .content section ul, .content section .contest-card {
            opacity: 0; transform: translateY(30px);
            transition: opacity 0.6s ease-out, transform 0.6s ease-out;
        }
        .content section.is-visible h2 {
            opacity: 1; transform: translateY(0); transition-delay: 0.1s;
            color: var(--navbar-orange); margin-bottom: 15px; border-bottom: 2px solid var(--link-green); padding-bottom: 5px;
        }
        .content section.is-visible h3 {
            opacity: 1; transform: translateY(0); transition-delay: 0.2s;
            color: var(--text-dark); margin-top: 20px; margin-bottom: 10px;
        }
        .content section.is-visible p { opacity: 1; transform: translateY(0); transition-delay: 0.25s; line-height: 1.6; }
        .content section.is-visible ul { opacity: 1; transform: translateY(0); transition-delay: 0.3s; list-style: disc; margin-left: 20px; }
        .content section.is-visible ul li { margin-bottom: 8px; }
        .content section.is-visible .contest-card { opacity: 1; transform: translateY(0); }
        .content section.is-visible .contest-card:nth-child(1) { transition-delay: 0.2s; }
        .content section.is-visible .contest-card:nth-child(2) { transition-delay: 0.3s; }

        .contests-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; }
        .contest-card {
            border: 1px solid #ddd; border-radius: 8px; padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); background-color: var(--page-bg-white);
            transition: transform 0.3s cubic-bezier(0.25, 0.8, 0.25, 1), box-shadow 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }
        .contest-card:hover { transform: translateY(-8px) scale(1.02); box-shadow: 0 10px 20px rgba(0,0,0,0.12), 0 4px 8px rgba(0,0,0,0.08); }
        .contest-card h3 { color: var(--link-green); margin-top: 0; }
        .contest-card img { width: 100%; max-height: 150px; object-fit: cover; border-radius: 4px; margin-bottom: 15px; }
        .join-button {
            background-color: var(--navbar-orange); color: var(--text-white); border: none;
            padding: 10px 20px; font-size: 1em; font-weight: bold; border-radius: 4px;
            cursor: pointer; transition: background-color 0.3s ease, transform 0.2s ease;
            display: inline-block; text-decoration: none;
        }
        .join-button:hover { background-color: #e6830d; transform: scale(1.05); }

        .modal {
            display: flex; align-items: center; justify-content: center;
            position: fixed; z-index: 1001; left: 0; top: 0; width: 100%; height: 100%;
            background-color: rgba(0,0,0,0.5); opacity: 0; visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
        }
        .modal.active { opacity: 1; visibility: visible; }
        .modal-content {
            background-color: #fefefe; margin: auto; padding: 25px; border: 1px solid #888;
            width: 90%; max-width: 500px; border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3); position: relative;
            transform: scale(0.95) translateY(10px); opacity: 0;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }
        .modal.active .modal-content { transform: scale(1) translateY(0); opacity: 1; }
        .close-button { color: #aaa; float: right; font-size: 28px; font-weight: bold; position: absolute; top: 10px; right: 20px; }
        .close-button:hover, .close-button:focus { color: black; text-decoration: none; cursor: pointer; }
        .modal-content h3 { margin-top: 0; color: var(--navbar-orange); }
        .modal-content label { display: block; margin-bottom: 8px; font-weight: bold; }
        .modal-content input[type="text"], .modal-content input[type="email"] { width: calc(100% - 22px); padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .modal-content button[type="submit"] { background-color: var(--link-green); color: white; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 1em; transition: background-color 0.3s, transform 0.2s ease; }
        .modal-content button[type="submit"]:hover { background-color: #106c07; transform: scale(1.03); }

        .flash-message { padding: 15px; margin-bottom: 20px; border: 1px solid transparent; border-radius: 4px; text-align: center; animation: elementSlideIn 0.5s ease-out 0.1s forwards; opacity: 0; }
        .flash-message.success { color: var(--success-text); background-color: var(--success-bg); border-color: var(--success-text); }
        .flash-message.error { color: var(--error-text); background-color: var(--error-bg); border-color: var(--error-text); }
        .flash-message.info { color: var(--info-text); background-color: var(--info-bg); border-color: var(--info-text); }

        footer { background-color: #333; color: var(--text-white); text-align: center; padding: 25px 0; margin-top: 40px; }
        footer .container { max-width: 960px; margin: 0 auto; padding: 0 20px; }
        .social-icons a { color: var(--text-white); margin: 0 10px; font-size: 1.5em; transition: color 0.3s ease, transform 0.3s ease; }
        .social-icons a:hover { color: var(--navbar-orange); transform: scale(1.1); }
        .social-icons .fa-heart { color: red; }

        @media (max-width: 992px) { .site-name { font-size: 1.3em; } .nav-links a { margin: 0 10px; } }
        @media (max-width: 768px) {
            .navbar-center {
                position: absolute; top: var(--navbar-height); left: 0; width: 100%;
                background: var(--navbar-orange); flex-direction: column; align-items: center;
                padding: 0; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-height: 0;
                overflow-y: auto; transition: max-height 0.4s ease-in-out, padding 0.4s ease-in-out;
            }
            .navbar-center.active { max-height: calc(100vh - var(--navbar-height) - 20px); padding: 10px 0; }
            .nav-links a { margin: 8px 0; padding: 12px 20px; width: 90%; text-align: center; box-sizing: border-box; border-radius: 4px; color: var(--text-white); }
            .nav-links a.active-link { background-color: rgba(0,0,0,0.1); color: var(--link-green); } /* Mobile active link style */
            .nav-links a:hover:not(.active-link) { background-color: rgba(255,255,255,0.15); opacity: 1; }
            .hamburger { display: block; margin-left: 15px; }
            .contests-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 480px) {
            .site-name { font-size: 1.1em; }
            .user-profile > span > span:not(.fa-caret-down) { display: none; }
            .user-icon { margin-right: 5px; }
            .content { padding: 20px; }
            .modal-content { padding: 20px; }
        }
    </style>
</head>
<body>

<div class="navbar">
    <div class="navbar-left">
        <img src="Assets/logo.png" alt="Site Logo" class="logo">
        <span class="site-name">EsportKheloIndia</span>
    </div>

    <div class="navbar-center nav-links" id="navLinks">
        <!-- <a href="home.php" class="<?php echo ($current_page_basename == 'home.php' || $current_page_basename == 'index.php') ? 'active-link' : ''; ?>">Home</a> -->
        <a href="profile.php#contests" class="<?php echo ($current_page_basename == 'profile.php' && $current_page_hash == 'contests') ? 'active-link' : ''; ?>">Contests</a>
        <a href="profile.php#rules" class="<?php echo ($current_page_basename == 'profile.php' && $current_page_hash == 'rules') ? 'active-link' : ''; ?>">Rules & Regulations</a>
        <a href="profile.php#terms" class="<?php echo ($current_page_basename == 'profile.php' && $current_page_hash == 'terms') ? 'active-link' : ''; ?>">Terms & Conditions</a>
        <a href="profile.php#report" class="<?php echo ($current_page_basename == 'profile.php' && $current_page_hash == 'report') ? 'active-link' : ''; ?>">Report</a>
    </div>

    <div class="navbar-right">
        <div class="user-profile" id="userProfileToggle">
            <i class="fas fa-user-circle user-icon"></i>
            <span><span>Hello, <?php echo htmlspecialchars($user_name); ?></span> <i class="fas fa-caret-down" style="font-size:0.8em;"></i></span>
            <div class="dropdown" id="userDropdown">
                <a href="profile.php"><i class="fas fa-user-edit"></i> My Profile</a>
                <a href="wallet.php"><i class="fas fa-wallet"></i> Wallet</a>
                <a href="my_winning.php"><i class="fas fa-trophy"></i> My Winnings</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
        <div class="hamburger" id="hamburgerMenu">
            <i class="fas fa-bars"></i>
        </div>
    </div>
</div>

<div class="content">
    <?php if (!empty($registration_message)): ?>
        <div class="flash-message <?php echo htmlspecialchars($registration_message_type); ?>">
            <?php echo htmlspecialchars($registration_message); ?>
        </div>
    <?php endif; ?>

    <h1>Welcome to your Profile, <?php echo htmlspecialchars($user_name); ?>!</h1>
    <p>Manage your information, view rules, and join contests from here.</p>

    <section id="contests" class="animate-on-scroll">
        <h2>Available Contests</h2>
        <p>Join our exciting esports contests! Prove your skills and win amazing prizes.</p>
        <div class="contests-grid">
            <div class="contest-card">
                <h3>BGMI Tournament</h3>
                <p>Showcase your Battlegrounds Mobile India skills. Squad up and fight for glory!</p>
                <p><strong>Mode:</strong> Classic Squads</p>
                <p><strong>Platform:</strong> Mobile</p>
                <button class="join-button" data-game-type="BGMI">Join BGMI Contest</button>
            </div>
            <div class="contest-card">
                <h3>Free Fire Challenge</h3>
                <p>Enter the Free Fire arena and battle it out. Booyah awaits the champion!</p>
                <p><strong>Mode:</strong> Battle Royale</p>
                <p><strong>Platform:</strong> Mobile</p>
                <button class="join-button" data-game-type="Free Fire">Join Free Fire Contest</button>
            </div>
        </div>
    </section>

    <section id="rules" class="animate-on-scroll">
        <h2>Rules & Regulations</h2>
        <p>Welcome to EsportKheloIndia! To ensure a fair, competitive, and enjoyable environment for all participants, we have established the following rules and regulations. All players are expected to adhere to these rules. Failure to comply may result in penalties, including disqualification, suspension, or permanent bans.</p>
        <h3>Fairplay Gameplay</h3>
        <p>Fair play is the cornerstone of competitive integrity. We expect all players to compete honestly and respect their opponents.</p>
        <ul>
            <li><strong>No Cheating:</strong> The use of any third-party software, hardware, scripts, or methods to gain an unfair advantage (e.g., aimbots, wallhacks, macros for unintended game mechanics) is strictly prohibited.</li>
            <li><strong>Account Sharing:</strong> Your account is for your personal use only. Account sharing or playing on behalf of another registered player is forbidden.</li>
        </ul>
        <h3>General Conduct</h3>
        <ul>
            <li><strong>Respect & Non-Discrimination:</strong> Harassment, discrimination, hate speech, or any form of abusive language or behavior towards other players, staff, or viewers will not be tolerated.</li>
        </ul>
         <h3>Game-Specific Rules</h3>
        <p>In addition to these general rules, each game or tournament may have its own specific rule set. It is the player's responsibility to read and understand all applicable game-specific rules before participating.</p>
    </section>

    <section id="terms" class="animate-on-scroll">
        <h2>Terms & Conditions</h2>
        <p>By registering for an account and/or participating in any tournament or event hosted by EsportKheloIndia ("we", "us", "our"), you ("player", "user", "participant") agree to be bound by these Terms and Conditions ("Terms"). Please read them carefully.</p>
        <h3>1. Eligibility</h3>
        <ul>
            <li>Participants must meet the age requirements specified for each tournament.</li>
        </ul>
        <h3>2. Account Registration</h3>
        <ul>
            <li>You must provide accurate and complete information during registration.</li>
        </ul>
        <p><em>(This is a sample. A comprehensive Terms & Conditions document would be much more detailed.)</em></p>
    </section>

    <section id="report" class="animate-on-scroll">
        <h2>Report an Issue / Player</h2>
        <p>If you have witnessed a violation of our Rules & Regulations, experienced technical difficulties, or need to report a player for misconduct, please provide as much detail as possible. Your report will be reviewed by our support team.</p>
        <p><strong>To submit a report, please email us at:</strong> <a href="mailto:support@esportkheloindia.com">support@esportkheloindia.com</a></p>
    </section>

</div>

<!-- Contest Join Modal -->
<div id="joinContestModal" class="modal">
    <div class="modal-content">
        <span class="close-button">×</span>
        <h3 id="modalContestTitle">Join Contest</h3>
        <form id="joinContestForm" method="POST" action="profile.php#contests">
            <input type="hidden" id="modalGameType" name="game_type" value="">
            <div>
                <label for="player_game_id">Player Game ID:</label>
                <input type="text" id="player_game_id" name="player_game_id" required>
            </div>
            <div>
                <label for="player_in_game_name">Player In-Game Name:</label>
                <input type="text" id="player_in_game_name" name="player_in_game_name" required>
            </div>
            <div>
                <label for="player_email">Your Email:</label>
                <input type="email" id="player_email_modal" name="player_email" value="<?php echo htmlspecialchars($user_email); ?>" required> <!-- Changed id to avoid conflict -->
            </div>
            <button type="submit" name="join_contest_submit">Submit Registration</button>
        </form>
    </div>
</div>


<footer>
    <div class="container">
        <div class="social-icons mb-3">
            <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="#" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
            <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
            <a href="#" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
            <a href="#" aria-label="Twitter"><i class="fab fa-x-twitter"></i></a>
        </div>
        <p>© <span id="currentYear"></span> eSportKhelegaIndia. All Rights Reserved. Designed with <i class="fas fa-heart" style="color:red;"></i>.</p>
    </div>
</footer>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const userProfileToggle = document.getElementById('userProfileToggle');
    const userDropdown = document.getElementById('userDropdown');
    const hamburgerMenu = document.getElementById('hamburgerMenu');
    const navLinksContainer = document.getElementById('navLinks'); // The container for nav links
    const navLinks = navLinksContainer.querySelectorAll('a'); // Individual nav links

    if (userProfileToggle && userDropdown) {
        userProfileToggle.addEventListener('click', function(event) {
            event.stopPropagation();
            userDropdown.classList.toggle('active');
        });
    }
    if (hamburgerMenu && navLinksContainer) {
        hamburgerMenu.addEventListener('click', function(event) {
            event.stopPropagation();
            navLinksContainer.classList.toggle('active'); // Toggle active on the container
            const icon = hamburgerMenu.querySelector('i');
            icon.classList.toggle('fa-bars');
            icon.classList.toggle('fa-times');
        });
    }
    document.addEventListener('click', function(event) {
        if (userDropdown && userDropdown.classList.contains('active') && !userProfileToggle.contains(event.target) && !userDropdown.contains(event.target)) {
            userDropdown.classList.remove('active');
        }
        if (navLinksContainer && navLinksContainer.classList.contains('active') && !navLinksContainer.contains(event.target) && !hamburgerMenu.contains(event.target) && !event.target.closest('.navbar')) {
             navLinksContainer.classList.remove('active');
             const icon = hamburgerMenu.querySelector('i');
             icon.classList.remove('fa-times');
             icon.classList.add('fa-bars');
        }
    });

    const currentYearSpan = document.getElementById('currentYear');
    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }

    const modal = document.getElementById('joinContestModal');
    const modalGameTypeInput = document.getElementById('modalGameType');
    const modalContestTitle = document.getElementById('modalContestTitle');
    const closeModalButton = modal.querySelector('.close-button'); // Renamed to avoid conflict
    const joinButtons = document.querySelectorAll('.join-button');

    function openModal() {
        modal.style.display = 'flex';
        setTimeout(() => { modal.classList.add('active'); }, 10);
    }
    function closeModal() {
        modal.classList.remove('active');
        const handleTransitionEnd = () => {
            if (!modal.classList.contains('active')) { modal.style.display = 'none'; }
            modal.removeEventListener('transitionend', handleTransitionEnd);
        };
        modal.addEventListener('transitionend', handleTransitionEnd);
    }

    joinButtons.forEach(button => {
        button.addEventListener('click', function() {
            const gameType = this.dataset.gameType;
            modalGameTypeInput.value = gameType;
            modalContestTitle.textContent = 'Join ' + gameType + ' Contest';
            const playerEmailInput = document.getElementById('player_email_modal'); // Use modal specific ID
            if (!playerEmailInput.value && '<?php echo !empty($user_email) ? "true" : "false"; ?>' === 'true') {
                 playerEmailInput.value = '<?php echo htmlspecialchars($user_email); ?>';
            }
            openModal();
        });
    });

    if(closeModalButton) { closeModalButton.addEventListener('click', closeModal); }
    window.addEventListener('click', function(event) {
        if (event.target == modal) { closeModal(); }
    });

    const sectionsToAnimate = document.querySelectorAll('.content section.animate-on-scroll');
    const observerOptions = { root: null, rootMargin: '0px', threshold: 0.15 };

    const sectionObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
            }
            // Optional: remove 'is-visible' when scrolling out if you want animation to replay
            // else { entry.target.classList.remove('is-visible'); }
        });
    }, observerOptions);
    sectionsToAnimate.forEach(section => { sectionObserver.observe(section); });


    // --- Dynamic active link highlighting for profile page sections on scroll ---
    const profileNavLinks = document.querySelectorAll('.navbar-center.nav-links a[href*="profile.php#"]');
    const contentSections = document.querySelectorAll('.content section[id]'); // Select sections within .content

    function changeActiveLinkOnScroll() {
        let currentSectionId = '';
        let passedFirstSection = false; // Flag to handle top of the page behavior

        contentSections.forEach(section => {
            const sectionTop = section.offsetTop - (document.querySelector('.navbar').offsetHeight + 40); // Adjusted offset
            const sectionBottom = sectionTop + section.offsetHeight;

            if (window.scrollY >= sectionTop && window.scrollY < sectionBottom) {
                currentSectionId = section.getAttribute('id');
                passedFirstSection = true;
            } else if (window.scrollY < sectionTop && !passedFirstSection) {
                // If we are above the first detected section, no section is "current" yet from scrolling
                // but we haven't passed the first one.
            }
        });
        
        // If scrolled past all sections, currentSectionId might remain the last one.
        // Or if at the very top, before any section is hit by the offset rule.

        profileNavLinks.forEach(link => {
            link.classList.remove('active-link');
            // Check if the link's hash matches the currentSectionId
            if (link.hash === `#${currentSectionId}`) {
                link.classList.add('active-link');
            }
        });

        // Default to "Contests" if on profile.php, no specific section is active via scroll, and no initial hash was set to something else
        if (window.location.pathname.includes('profile.php')) {
            const currentActive = document.querySelector('.navbar-center.nav-links a.active-link[href*="profile.php#"]');
            if (!currentActive && (!window.location.hash || window.location.hash === "#")) { // No active link AND no hash or just "#"
                 const contestsLink = document.querySelector('.navbar-center.nav-links a[href="profile.php#contests"]');
                 if (contestsLink) contestsLink.classList.add('active-link');
            }
        }
    }

    if (window.location.pathname.includes('profile.php')) {
        window.addEventListener('scroll', changeActiveLinkOnScroll);
        // Initial call on page load to set active link based on hash or default
        const initialHash = window.location.hash;
        let foundActiveByHash = false;
        if (initialHash) {
            profileNavLinks.forEach(link => {
                if (link.hash === initialHash) {
                    link.classList.add('active-link');
                    foundActiveByHash = true;
                } else {
                    link.classList.remove('active-link');
                }
            });
        }
        if(!foundActiveByHash && (!initialHash || initialHash === "#")) { // If no hash or just '#', make 'Contests' active by default
             const contestsLink = document.querySelector('.navbar-center.nav-links a[href="profile.php#contests"]');
             if(contestsLink) contestsLink.classList.add('active-link');
        }
        // Call after a small delay to let layout settle, especially if there's a jump to hash
        setTimeout(changeActiveLinkOnScroll, 50);
    }
    // --- End dynamic active link ---


    // Smooth scroll to section if hash exists (after other animations might have settled)
    if (window.location.hash) {
        const element = document.querySelector(window.location.hash);
        if (element) {
            setTimeout(() => {
                element.scrollIntoView({ behavior: 'smooth' });
                 if (window.location.pathname.includes('profile.php')) {
                    changeActiveLinkOnScroll(); // Re-check active link after scroll
                }
            }, 250); 
        }
    }
});
</script>
</body>
</html>